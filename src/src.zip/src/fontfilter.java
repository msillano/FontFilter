//@source: D:\User\Documents\progetti2016\stickfonts\font_filter\src\fontfilter.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  http://gnu.org/licenses/gpl.html
*/
// package and import
import java.io.*;
import java.nio.charset.Charset;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.text.SimpleDateFormat;
import ms.utils.aarray.baseapp.AABaseAppl;
import ms.utils.aarray.baseapp.filter.ZeroFilter;
import ms.utils.fonts.Cchar;
import ms.utils.fonts.Cfont;
import ms.utils.DMath;

 /**
 * This application implements some glyphs filter funcitons, to modify the
 * font apparence and to produce a "single line font", for CNC use
 * from any TTF/CHR font.<br>
 *
 *
 * It reads the input stream, an ASCCI font file in CHR format, processes all (or part)
 * the glyphs using the filter and the parameters defined in the config file, and outputs
 * the modified glyphs as CHR or SVG font file.
 *
 * <h4> Implemented FILTERS </h4>
 * NULL <br>
 *   Does nothing, useful to transform a CHR font in a CVS font.
 *
 * QUAD <br>
 *   Transforms all glyphs using a biquadratic map. This allows many global effectcs, like italic,
 *   mirrow, deformations, etc.
 *
 * MANYQUAD <br>
 *   Transforms and remaps the select glyphs using a specific quadratic maps.
 *   Useful for comparative tests and fine tuneup of quadratic maps using one or few glyphs.
 *   See fontfilter.ffc.
 *
 * EVAL <BR>
 *   for non-linear expression, in JavaScript,
 *   see DMath.java
 *
 * SKELETON
 *   a experimental filter for glyph shrink process
 *
 *
 *
 * Extends ZeroFilter defining private data
 * structures: version, help, Option, Parameter and default datFile name.<BR>
 * Input/Output from/to files or standard in/out. <BR>
 * If the Option "x" is true, the datFile file is in XML format, else datFile is
 * in plain text format (INI like). This application can read options from command
 * line or from the config file.
 *
 * <br />Source build by JStruct [charset UTF-8].<br />
 * @author (c)2016 M. Sillano (marco.sillano@gmail.com)
 * @version 1.03 build 18  (2016.01.10-14:55:51): Java 1.8, start version
 * @version 2.03 build 74  (2017.02.10-14:55:51): Java 1.8, updated skeleton build, added EVAL
*/
public class fontfilter
extends ms.utils.aarray.baseapp.filter.ZeroFilter {

   /* class global variables */
   // standard ZeroFIle extensions
   private static final String shortVersion = "FontFilter 2.03 (17/02/10)";
   private static final String version =  shortVersion+" \n"+
                                         "Copyright (C)2016,2017  M.Sillano \n"+
                                         "License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html> \n"+
                                         "This is free software: you are free to change and redistribute it. \n"+
                                         "There is NO WARRANTY, to the extent permitted by law.";
   private static final String[] fontHelp = {
          "Usage:     fontfilter -h|-?|--help|--version",
          "           fontfilter [-x] [-i=FILE] [-o=FILE] [ffcFile]",
          "Filters the CHR inputFile, modifies the glyphs, outputs as CHR or SVG font file",
          "options:  -h|-?|--help    display this help and exit.",
          "          --version       print version and exit.",
          "          -x              ffcFile in XML mode. Default = plain text.",
          "-i=FILE, --input=FILE     the font.chr input file, overwite default in ffcFile, mandatory.",
          "-o=FILE, --output=FILE    the .chr/.svg font output file, overwite default in ffcFile",
          " ffcFile:                 configuration file. Default = fontfilter.ffc."};

   private static final String Opts = "x";
   //
   private static final String[] Params = {"-input", "i", "-output", "o"};
   //
   private static final String DEFAULT_CONFIG = "fontfilter.ffc";
   private static final String FILETITLE = "by fontfilter 2.03 (17/02/10)";
   // end standard stuff
   // ================================== config file constants
   public static final String[] FUNCTIONS = {
             "NULL",
             "QUAD",
             "MANYQUAD",
             "EVAL",
             "SKELETON"
   };
   public static final String ffc_function = "function";
   // function QUAD
   public static final String ffc_QUAD_map = "qmFINAL";
   // function QUAD
   public static final String ffc_MANYQUAD_prefix = "QM_";

   //===================================
   private static boolean outSVG = true;
   private static Cfont<Cchar> CHRfont;

/**
 * Initializes aaBase and all custom data structures. It uses
 * ZeroFilter.startup for input/output standard processing.
 *
 * @param args
 *            command line from main().
 */
   protected static void startup(String[] args) {
// =======================================================
// static setup
      AABaseAppl.version = fontfilter.version;
      AABaseAppl.helpStrings = fontfilter.fontHelp;
      AABaseAppl.fileTitle = fontfilter.FILETITLE;
// Dynamic setup
      aaBase = new AABaseAppl(Opts, Params);
      aaBase.setConfigFile(DEFAULT_CONFIG);
      ZeroFilter.startup(args);

 // end standard setup
// =======================================================
        if (aaBase.getConfigFile()==null)  // i.e. config not found
         exampleCfgAndDies();
// more setup for fontfilter
      CHRfont = new Cfont <Cchar> (255, aaBase);
      if (outFile.getName().toLowerCase().endsWith(".chr"))
            outSVG = false;
 //     aaBase.list(System.out);
      try {
      CHRfont.setQCoeff(CHRfont.finalQM, aaBase.getProperty(ffc_QUAD_map));
      }  catch(Exception e){
       aaBase.helpAndDies("ERROR in CONFIG ("+aaBase.getConfigFile()+"): bad map for "+ffc_QUAD_map, 1);
             }
  DMath.precision     = Double.parseDouble(aaBase.getProperty("mathPrecision").trim());
  DMath.attractRadius = Double.parseDouble(aaBase.getProperty("attractRadius").trim());
  return;
   }

/**
 * Creates a example datFile and exit PROCESS_FAILURE;
 * TODO default conf file
 */
   private static void exampleCfgAndDies() {
      aaBase.cleanAllSpecial(true, true);
      aaBase.saveConfigFile(DEFAULT_CONFIG);
      aaBase.helpAndDies("ERROR: not found configuration file " + DEFAULT_CONFIG);
   }

/**
 * NOTE maybe useful
 * @return String
 */
   private static String getDefaultCharSet() {
      OutputStreamWriter writer = new OutputStreamWriter(new ByteArrayOutputStream());
      String enc = writer.getEncoding();
      return enc;
   }
/**
 * The method... do_output_dump
 */
   private static void do_output_dump() {
      if(outSVG) {
         CHRfont.dumpSVG(fout,0,0x7FFF);
      }
      else {
         CHRfont.dumpCHR(fout,0,0x7FFF);
      }
   }
   private static void do_limit_dump() {
      if(outSVG) {
         CHRfont.dumpSVG(fout,CHRfont.getSKstart(),CHRfont.getSKend());
      }
      else {
         CHRfont.dumpCHR(fout,CHRfont.getSKstart(),CHRfont.getSKend());
      }
   }



/**
 * The method... do_test_qm
 */
   static void do_test_qm() {
      if(outSVG) {
         CHRfont.pre_outputSVG(fout);
      }

      Iterator <String> getKey = aaBase.stringPropertyNames().iterator();
      while(getKey.hasNext()) {
         String key = getKey.next();
         if(key.toUpperCase().startsWith(ffc_MANYQUAD_prefix)) {
            String value = aaBase.getProperty(key);
            int pos = value.indexOf(';');
            int code = Integer.parseInt(key.substring(3), 16);
            String newName = CHRfont.getGlyphName(code, null);
            Cchar outCHR = CHRfont.getCharFromName(value.substring(0, pos).trim());

            System.out.println("==== char "+outCHR.getName()+ " to char("+code+") "+newName );
            try {
            CHRfont.setQCoeff(CHRfont.testQM, value.substring(pos + 1));
             }
             catch(Exception e){
                aaBase.helpAndDies("ERROR in CONFIG ("+aaBase.getConfigFile()+"): bad map for "+key, 1);
             }
            CHRfont.setQScale(CHRfont.testQM);
            if(outSVG) {

               fout.println(outCHR.dumpSVG(newName, CHRfont.svg_chrScale, CHRfont.testQM));
               }
            else {
               fout.println(outCHR.dumpCHR(code, CHRfont.testQM));
            }
         }
      }
      if(outSVG) {
         CHRfont.post_outputSVG(fout);
      }
   }

/**
 * The method... do_test_eval
 */
   static void do_test_eval() {
      String expx = aaBase.getProperty("newX");
      String expy = aaBase.getProperty("newY");
      System.out.println("  x' function: " +expx);
      System.out.println("  y' function: " +expy);
      CHRfont.jseval( expx, expy);
    }

/**
 * The method... do_explosion
 * in Cchar Class
 */
   private static void do_explode() {
      CHRfont.explode();
   }


/**
 * The main is static. This main uses this.startup() to eval Options and
 * Params.
 * Then chhose the required filter function.
 *
 * @param args
 *            command line argoments array processed by startup().
 */
   public static void main(String[] args) {
       startup(args);
       try
       {
// reads the CHR input font
         String n = inFile.getName();
         String baseName = n.substring(0, n.indexOf('.'));
         CHRfont.addChars(fin,baseName);
 // ======== filter processing
         System.out.println(shortVersion);
         System.out.println("input file: "+inFile.getCanonicalPath() );
         String outFun = aaBase.getProperty("function").toUpperCase();
         if (outFun.equals(FUNCTIONS[4]))
              System.out.println("  function "+outFun + " output " + aaBase.getProperty("SKoutput").toUpperCase() );
         else
              System.out.println("  function "+outFun);

 // NULL
         if(outFun.equals(FUNCTIONS[0])) {
            System.out.println("  font "+baseName + "( from "+CHRfont.getSKstart()+" to "+CHRfont.getSKend()+") to " +CHRfont.getFontName());
            CHRfont.setQCoeff(CHRfont.finalQM, "0;0;0;0;1;0; 0;0;0;0;0;1");
            CHRfont.setQScale(CHRfont.finalQM);
            do_limit_dump();
         }
// QUAD
         if(outFun.equals(FUNCTIONS[1])) {
            CHRfont.setFontName(baseName+"_quad");
            System.out.println("  font "+baseName + "(from "+CHRfont.getSKstart()+" to "+CHRfont.getSKend()+") to " +CHRfont.getFontName());
            CHRfont.setQCoeff(CHRfont.finalQM, aaBase.getProperty(ffc_QUAD_map));
            CHRfont.setQScale(CHRfont.finalQM);
            do_limit_dump();
         }
// MANYQUAD
         if(outFun.equals(FUNCTIONS[2])) {
            CHRfont.setFontName(baseName+"_manyquad");
            System.out.println("  font "+baseName + " to " +CHRfont.getFontName());
            do_test_qm();
         }
// EVAL
         if(outFun.equals(FUNCTIONS[3])) {
            CHRfont.setFontName(baseName+"_eval");
            System.out.println("  font "+baseName + "(from "+CHRfont.getSKstart()+" to "+CHRfont.getSKend()+") to " +CHRfont.getFontName());
            CHRfont.setQCoeff(CHRfont.finalQM, "0;0;0;0;1;0; 0;0;0;0;0;1");
            CHRfont.setQScale(CHRfont.finalQM);
            do_test_eval();
            do_limit_dump();
         }

// EXPLOSION
         if(outFun.equals(FUNCTIONS[4])) {
           CHRfont.setFontName(baseName+"_explode");
           System.out.println("  font "+baseName + "(from "+CHRfont.getSKstart()+" to "+CHRfont.getSKend()+") to " +CHRfont.getFontName());
           CHRfont.setQCoeff(CHRfont.finalQM, "0;0;0;0;1;0; 0;0;0;0;0;1");
           CHRfont.setQScale(CHRfont.finalQM);
           do_explode();
           do_limit_dump();
         }

//======= final stuff
         fin.close();
         fout.flush();
         fout.close();
         System.out.println("output file: "+outFile.getCanonicalPath() );
      }
      catch (Exception e) {
         System.err.println("FATAL ERROR");
         e.printStackTrace();
         System.exit(AABaseAppl.PROCESS_FAILURE);
      }
   }

}
