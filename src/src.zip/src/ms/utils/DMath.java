//
// math and basic geom point stuff, trace
//
//@source: D:\User\Documents\progetti2016\stickfonts\font_filter\src\ms\ utils\DMath.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
// package and import
package ms.utils;

import javax.script.ScriptEngineManager;
import javax.script.ScriptEngine;
import javax.script.ScriptException;
import java.util.List;
import java.util.ArrayList;
/**
 * Class DMath
 * Math and some geometrical stuff (static)
 * <br />Source build by JStruct [charset UTF-8].<br />
 *@version 1.00.00  build 6 2016.01.21
 *@version 1.01.00  build 2 2017.03.18
 * added jsEval()
 *@author Sillano
 */
//http://stackoverflow.com/questions/3422673/evaluating-a-math-expression-given-in-string-form
//http://www.javascripter.net/faq/mathfunc.htm

/*
Compound assignment operators

Assignment                  x = y           x = y
Addition assignment         x += y          x = x + y
Subtraction assignment      x -= y          x = x - y
Multiplication assignment   x *= y          x = x * y
Division assignment         x /= y          x = x / y
Remainder assignment        x %= y          x = x % y
Exponentiation assignment   x **= y         x = x ** y
Left shift assignment       x <<= y         x = x << y
Right shift assignment      x >>= y         x = x >> y
Unsigned right shift ass.   x >>>= y        x = x >>> y
Bitwise AND assignment      x &= y          x = x & y
Bitwise XOR assignment      x ^= y          x = x ^ y
Bitwise OR assignment       x |= y          x = x | y


Bitwise operators

Bitwise AND                 a & b           Returns a one in each bit position for which the corresponding bits of both operands are ones.
Bitwise OR                  a | b           Returns a zero in each bit position for which the corresponding bits of both operands are zeros.
Bitwise XOR                 a ^ b           Returns a zero in each bit position for which the corresponding bits are the same.
                                              [Returns a one in each bit position for which the corresponding bits are different.]
Bitwise NOT                 ~ a             Inverts the bits of its operand.
Left shift                  a << b          Shifts a in binary representation b bits to the left, shifting in zeros from the right.
Sign-propagating rgt shift  a >> b          Shifts a in binary representation b bits to the right, discarding bits shifted off.
Zero-fill right shift       a >>> b

Logical operators

Logical AND (&&)           expr1 && expr2   Returns expr1 if it can be converted to false; otherwise, returns expr2.
                                            Thus, when used with Boolean values, && returns true if both operands are true; otherwise, returns false.
Logical OR (||)            expr1 || expr2   Returns expr1 if it can be converted to true; otherwise, returns expr2.
                                            Thus, when used with Boolean values, || returns true if either operand is true; if both are false, returns false.
Logical NOT (!)           !expr             Returns false if its single operand can be converted to true; otherwise, returns true.

Comparison Operators

Given that x = 5, the table below explains the comparison operators:

Operator
==      equal to
     x == 8  false
     x == 5  true
     x == "5"    true
=== equal value and equal type
     x === 5 true
     x === "5"   false
!=  not equal   x != 8  true
!== not equal value or not equal type   x !== 5 false
     x !== "5"   true
     x !== 8 true
>   greater than    x > 8   false
<   less than   x < 8   true
>=  greater than or equal to    x >= 8  false
<=  less than or equal to   x <= 8  true

The 'in' operator returns true if the specified property is in the specified object, otherwise false:
            example: var cars = ["Saab", "Volvo", "BMW"]; if("Saab" in cars) ...  true

*Unary operations have one operand (in the following examples, the operand is a):
-a   // change the sign of a
~a   // bitwise NOT a
++a  // add 1 to a (before using a)
a++  // add 1 to a (after using a)
--a  // subtract 1 from a (before using a)
a--  // subtract 1 from a (after using a)

Binary operations have two operands (in these examples, the operands are a and b):

a * b    // multiply a by b
a / b    // divide a by b
a % b    // find the remainder of division of a by b
a + b    // add a and b
a - b    // subtract b from a
a & b    // bitwise a AND b
a | b    // bitwise a OR b
a ^ b    // bitwise a XOR b

Shifts are the following operations:

a << b   // shift a by b bits to the left
         // (padding with zeros)
a >> b   // shift a by b bits to the right
         // (copying the sign bit)
a >>> b  // shift a by b bits to the right
         // (padding with zeros)

functions:

Math.abs(a)     // the absolute value of a
Math.acos(a)    // arc cosine of a
Math.asin(a)    // arc sine of a
Math.atan(a)    // arc tangent of a
Math.atan2(a,b) // arc tangent of a/b
Math.ceil(a)    // integer closest to a and not less than a
Math.cos(a)     // cosine of a
Math.exp(a)     // exponent of a (Math.E to the power a)
Math.floor(a)   // integer closest to a, not greater than a
Math.log(a)     // log of a base e
Math.max(a,b)   // the maximum of a and b
Math.min(a,b)   // the minimum of a and b
Math.pow(a,b)   // a to the power b
Math.random()   // pseudorandom number 0 to 1 (see examples)
Math.round(a)   // integer closest to a (see rounding examples)
Math.sin(a)     // sine of a
Math.sqrt(a)    // square root of a
Math.tan(a)     // tangent of a

Conditional (Ternary) Operator
   variablename = (condition) ? value1:value2  Example: var voteable = (age < 18) ? "Too young":"Old enough";

The comma operator evaluates each of its operands (from left to right) and returns the value of the last operand.
          expr1, expr2, expr3...(Any expression).
*/
public final class DMath {

   /* class global variables */
   /* to be updated from cfg file */
   public static double precision     = 0.00001;
   public static double attractRadius = 0.14;
   // fot jsEval:
   public static ScriptEngine jsEngine = null;

   //======  for debug, banal trace faculty
   public static boolean trace = false;
   public static boolean tracelocal = false;

   public static void tracelocal(String msg){
    if (trace && tracelocal) System.out.println(msg);
   }
   public static void trace(String msg){
    if (trace) System.out.println(msg);
   }
/**
 * The method... quasiEqual
 * @param a double
 * @param b double
 * @return boolean
 */
 public static boolean quasiEqual(double a, double b) {
      return Math.abs(a - b) < precision;
   }


public static Double jsEval(String script) {
    if (jsEngine == null){
     ScriptEngineManager mgr = new ScriptEngineManager();
     jsEngine =  mgr.getEngineByName("JavaScript");
    }
    try
    {
    return (Double) jsEngine.eval(script);
     }
    catch (ScriptException ex)
    {
        ex.printStackTrace();
        return 0.0;
    }
}

 public static void main(String args[]) {
// to test eval()
    List<String> namesList = new ArrayList<String>();
    namesList.add("Jill");
    namesList.add("Bob");
    namesList.add("Laureen");
    namesList.add("Ed");
    System.out.println("Executing in script environment...");
//test 1
  //  String exp1 = "var x = 5.1; var y = 3.2; x*x + 2.1*y";
   String exp1 = "x = 5.1,y = 3.2, x*x + 2.1*y + Math.sin(x) ";

    Double r = jsEval(exp1);
    System.out.println(" Result = "+r);
//test 2
    jsEngine.put("namesListKey", namesList);
    jsEval("var x;" +
                    "var names = namesListKey.toArray();" +
                    "for(x in names) {" +
                    "  print(names[x]);" +
                    "}" +
                    "namesListKey.add(\"Dana\"); 3.1;");  // added 3.1 to return double, else Boolean
// test 3
//  String exp3 = "var f = new java.io.FileWriter('hello.txt'); f.write('UNLIMITED POWER!'); f.close();1.0;";
//  Double s = jsEval(exp3);

   }

/**
 * determinant:
 *  | n00  n01 |
 *  | n10  n11 |
 * @return double
 */
   public static double det(double n00, double n01, double n10, double n11) {
      return(n00 * n11 - n01 * n10);
   }

/**
 * distance point A to point B
 * @param Ax double
 * @param Ay double
 * @param Bx double
 * @param By double
 * @return double
 */
   public static double distance(double Ax, double Ay, double Bx, double By) {
      return Math.sqrt((Ax - Bx) * (Ax - Bx) + (Ay - By) * (Ay - By));
   }

/**
 * done 2 segments AB and CD find if parallel
 * @param Ax double
 * @param Ay double
 * @param Bx double
 * @param By double
 * @param Cx double
 * @param Cy double
 * @param Dx double
 * @param Dy double
 * @return boolean
 */
   public static boolean isParallel(double Ax, double Ay, double Bx, double By, double Cx, double Cy, double Dx, double Dy) {
// vertical
      if(quasiEqual(Ax, Bx) && quasiEqual(Cx, Dx)) {
         return true;
      }
// horizontal
      if(quasiEqual(Ay, By) && quasiEqual(Cy, Dy)) {
         return true;
      }
 // AB parallel CD ?
    double delta = DMath.det((Bx - Ax), (By - Ay), (Dx - Cx), (Dy - Cy));
//    return  Math.abs(delta) <   (Math.abs((By - Ay)*(Dx - Cx)) *attractRadius);
      return  Math.abs(delta) <   ( 0.1*attractRadius);
 //   return (quasiEqual(delta, 0));
   }


  public static double triangleSurface(double Ax, double Ay, double Bx, double By, double Cx, double Cy) {
      return DMath.det((Cx - Ax), (Cy - Ay), (Bx - Ax), (By - Ay))*0.5;
   }


/**
 * done 2 segments AB and CD find if collinear
 * @param Ax double
 * @param Ay double
 * @param Bx double
 * @param By double
 * @param Cx double
 * @param Cy double
 * @param Dx double
 * @param Dy double
 * @return boolean
 */
   public static boolean isCollinear(double Ax, double Ay, double Bx, double By, double Cx, double Cy, double Dx, double Dy) {
// is AB parallel to CD ?
      if(!isParallel(Ax, Ay, Bx, By, Cx, Cy, Dx, Dy)) {
         return false;
      }
// is AC parallel to BD ?
      if(!isParallel(Ax, Ay, Cx, Cy, Bx, By, Dx, Dy)) {
         return false;
      }
// is AD parallel to BC ?
      if(!isParallel(Ax, Ay, Dx, Dy, Bx, By, Cx, Cy)) {
         return false;
      }
      return true;
   }

}
