//@source: D:\User\Documents\progetti2016\stickfonts\font_filter\src\ms\ utils\fonts\Cchar.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
// package and import
package ms.utils.fonts;

import ms.utils.DMath;
import ms.utils.aarray.baseapp.AABaseAppl;
import ms.utils.fonts.Cpoint;
import ms.utils.fonts.Cpath;
import ms.utils.fonts.Cfont;
import ms.utils.fonts.skeleton.SMoto;
import ms.utils.fonts.skeleton.SDrome;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * this class contain many useful method for character management and transformation
 *it is a list of phats
 * <br />Source build by JStruct [charset UTF-8].<br />
 * @version 1.00.00  build 10  (2016.02.21-14:07:26)
 * @author (c)20016 M. Sillano (marco.sillano@gmail.com)
 */
public class Cchar <E>
extends ArrayList<E> {

   /* class global variables */
   SDrome myDrome = null;
   private int code;
   private int width;
   private double minX;
   private double maxX;
   private double minY;
   private double maxY;
   String glyphName;
   String unicode;
   String characterName;
   private Cfont font;
   boolean done = false;

/**
 * ===========================  SETTER/GETTERS
 * The method... getCodeCHR
 * @return int
 */
   public AABaseAppl getBaseApp() {
      return font.getBaseApp();
   }

/**
 * The method... getCode
 * @return int
 */
   public int getCode() {
      return code;
   }

/**
 * The method... getName
 * @return String
 */
   public String getName() {
      return glyphName;
   }

/**
 * The method... getMinX
 * @return double
 */
   public double getMinX() {
      return minX;
   }

/**
 * The method... getMaxX
 * @return double
 */
   public double getMaxX() {
      return maxX;
   }

/**
 * The method... getMinY
 * @return double
 */
   public double getMinY() {
      return minY;
   }

/**
 * The method... getMaxY
 * @return double
 */
   public double getMaxY() {
      return maxY;
   }

/**
 * The method... getWidth
 * @return int
 */
   public int getWidth() {
      return width;
   }

/**
 * The method... myFont
 * @return Cfont
 */
   public Cfont myFont() {
      return font;
   }

/**
 * The method... getDrome
 * @return SDrome
 */
   public SDrome getDrome() {
      return myDrome;
   }

/**
 * The method... getPathCount
 * @return int
 */
   public int getPathCount() {
      return this.size();
   }

/**
 * The method... getPathPointCount
 * @param path int
 * @return int
 */
   public int getPathPointCount(int path) {
      return((ArrayList <Cpath>) this).get(path).size();
   }

/**
 * The method... getCharPointCount
 * @return int
 */
   public int getCharPointCount() {
      int n = 0;
      for(Cpath cp : (ArrayList <Cpath>) this) {
         n += cp.size();
      }
      return n;
   }

/**
 * The method... getCharPoint
 * @param i int
 * @return Cpoint
 */
   public Cpoint getCharPoint(int i) {
      int k = i;
      for(Cpath cp : (ArrayList <Cpath>) this) {
         if(k < cp.size()) {
            return(Cpoint) cp.get(k);
         }
         else {
            k -= cp.size();
         }
      }
      return null;
   }

/**
 * The method... charIndexOf
 * @param p Cpoint
 * @return  int
 */
   public int charIndexOf(Cpoint p) {
      int k = 0;
      for(Cpath cp : (ArrayList <Cpath>) this) {
         int w = cp.indexOf(p);
         if(w == - 1) {
            k += cp.size();
         }
         else {
            return k + w;
         }
      }
      return - 1;
   }

/**
 * The method... attraction
 * @param p Cpoint
 * @return Cpoint
 */
   public Cpoint attraction(Cpoint p) {
      if(getDrome() == null) {
         return p;
      }
      Cpoint p2 = p;
      double farp = 500;
      for(SMoto m : ((ArrayList <SMoto>) getDrome())) {
// TODO why null here?
         if((m.eventDone() || m.eventIntersection()) && m.end != null && p.distance(m.end) < farp) {
            farp = p.distance(m.end);
            p2 = m.end;
         }
         if((m.eventDone() || m.eventProcessable()) && m.start != null && p.distance(m.start) < farp) {
            farp = p.distance(m.start);
            p2 = m.start;
         }
      }
      if(farp < DMath.attractRadius) {
         return p2;
      }
      return p;
   }

/**
 * The method... isSamePath
 * @param px Cpoint
 * @param py Cpoint
 * @return boolean
 */
   boolean isSamePath(Cpoint px, Cpoint py) {
      return px.getPath() == py.getPath();
   }

/**
 * ===========================  CONSTRUCTORS
 * The constructor Cchar
 * @param code Integer
 * @param schar String
 * @param font Cfont
 */
   public Cchar(Integer code, String schar, Cfont font) {
      super();
      this.font = font;
      this.code = remap(code);
      if(schar != null) {
         String[] frames = schar.split(";");
         width = Integer.parseInt(frames[0]);
         for(int i = 1; i < frames.length; i++) {
            this.add((E) new Cpath <Cpoint> (frames[i].trim(), this));
         }
      }
      font.getGlyphName(code, this);
      if (code >= this.font.getSKstart() && code <= this.font.getSKend()){

      killNearPoints();
      splitLongLines();
      }
      setMinMax();
   }

/**
 *   for debug
 * ===========================  PUBLIC
 * The method... addPointGlyph
 * @param x double
 * @param y double
 * @param size double
 */
   public void addSquarePointGlyph(double x, double y, double size) {
      Cpath cp = new Cpath(this);
      cp.add(new Cpoint(x + size, y + size, cp));
      cp.add(new Cpoint(x + size, y - size, cp));
      cp.add(new Cpoint(x - size, y - size, cp));
      cp.add(new Cpoint(x - size, y + size, cp));
      cp.add(new Cpoint(x + size, y + size, cp));
      this.add((E) cp);
   }

/**
 * for debug
 * @param x double
 * @param y double
 * @param size double
 */
   public void addCrossPointGlyph(double x, double y, double size) {
      Cpath cp = new Cpath(this);
      cp.add(new Cpoint(x, y, cp));
      cp.add(new Cpoint(x, y + size, cp));
      cp.add(new Cpoint(x, y - size, cp));
      cp.add(new Cpoint(x, y, cp));
      cp.add(new Cpoint(x + size, y, cp));
      cp.add(new Cpoint(x - size, y, cp));
      cp.add(new Cpoint(x, y, cp));
      this.add((E) cp);
   }

/**
 * The method... addNewLine
 * @param a Cpoint
 * @param b Cpoint
 */
   public void addNewLine(Cpoint a, Cpoint b) {
      Cpath lp = new Cpath(this);
      lp.add(a.setVisible(lp));
      lp.add(b.setVisible(lp));
      lp.add(a.setVisible(lp));
      this.add((E) lp);
   }

/**
 * ================================= dump char
 *
 * The method... dumpCHR
 * @return String
 */
   public String dumpCHR() {
      return dumpCHR(code, myFont().finalQM);
   }

/**
 *  System.out.println("**Xmin="+minX+" Xmax="+maxX+" Ymin="+minY+" Ymax="+maxY);
 *  System.out.println("**Char "+glyphName+" ="+characterName);
 * The method... dumpCHR
 * @return String
 * @param code_to int
 * @param coeff double[]
 */
   public String dumpCHR(int code_to, double[] coeff) {
      String p = "CHR_" + Integer.toHexString(inversemap(code_to)).toUpperCase();
      p += " " + Integer.toString(width);
      if(width == 0) {
         return p;
      }
      String s = "";
      for(Cpath cp : (ArrayList <Cpath>) this) {
         if(getBaseApp().getProperty("SKoutput").equals("TEST") || getBaseApp().getProperty("SKoutput").equals("TEST0") || cp.isBase()) {
            s += (s == "" ? "" : "; ") + cp.dumpCHR(coeff);
         }
      }
      return p + "; " + s;
   }

/**
 * The method... dumpSVG
 * @return String
 * @param scale double
 * @param glyphTo String
 * @param coeff double[]
 */
   public String dumpSVG(String glyphTo, double scale, double[] coeff) {
      String p = " <glyph glyph-name=\"" + glyphTo + "\"";
      if(width == 0) {
         return p + " horiz-adv-x=\"4000\" />";
      }
      else {
         double advan = myFont().xQuadratic(coeff, maxX, maxY) - myFont().xQuadratic(coeff, minX, minY);
         p += " horiz-adv-x=\"" + Math.round(advan * scale) + "\" ";
      }
      String s = " d=\"";
      for(Cpath cp : (ArrayList <Cpath>) this) {
// output style TEST: also added lines, else only base Cpath
         if(getBaseApp().getProperty("SKoutput").equals("TEST") || getBaseApp().getProperty("SKoutput").equals("TEST0") || cp.isBase()) {
            s += cp.dumpSVG(scale, coeff);
         }
      }
      return p + s + "\" />";
   }

/**
 * The method... dumpSVG
 * @param scale double
 * @return String
 */
   public String dumpSVG(double scale) {
      return dumpSVG(glyphName, scale, myFont().finalQM);
   }


public void jseval(String xexp, String yexp){
      for(Cpath cp : (ArrayList <Cpath>) this) {
         for(Cpoint p : (ArrayList <Cpoint>) cp) {
            String params = "x="+ p.x+"; y=" + p.y +"; " ;
            p.x=DMath.jsEval(params+xexp+";");
 //          System.out.println(" p.x = " + p.x + "(" +params+xexp+";)");
            p.y=DMath.jsEval(params+yexp+";");
 //          System.out.println(" p.y = " + p.y + "(" +params+yexp+";)");
          }
      }
 }

/**
 * ===========================  private
 * The method... setMinMax
 */
   private void setMinMax() {
      minX = 1000;
      maxX = - 1000;
      minY = 1000;
      maxY = - 1000;
      for(Cpath cp : (ArrayList <Cpath>) this) {
         for(Cpoint p : (ArrayList <Cpoint>) cp) {
            if(p.x < minX) {
               minX = p.x;
            }
            if(p.x > maxX) {
               maxX = p.x;
            }
            if(p.y < minY) {
               minY = p.y;
            }
            if(p.y > maxY) {
               maxY = p.y;
            }
         }
      }
// adjust for "space" glyph
      if(minX == 1000) {
         minX = maxX = minY = maxY = 0;
      }
   }

/**
 * The method... remap
 * @param nchr int
 * @return int
 */
   private int remap(int nchr) {
      return nchr;
   }

/**
 * The method... inversemap
 * @param nchr int
 * @return int
 */
   private int inversemap(int nchr) {
      return nchr;
   }

/**
 * The method... stepKillNear
 * used by killNearPoints
 * @param minLine Double
 * @return boolean
 */
   private boolean stepKillNear(Double minLine) {
      for(Cpath cp : (ArrayList <Cpath>) this) {
         for(int i = 0; i < cp.size() - 1; i++) {
            Cpoint p = (Cpoint) cp.get(i);
            if(p.distance((Cpoint) cp.get(i + 1)) < minLine) {
               if(i == cp.size() - 2) {
                  cp.remove(i);
               }
               else {
                  cp.remove(i + 1);
               }
               return true;
            }
         }
      }
      return false;
   }

/**
 * The method... killNearPoints
 * eliminates near points (less than "smallLine")
 */
   private void killNearPoints() {
      int count = 0;
      Double minLine = Double.parseDouble(getBaseApp().getProperty("smallLine"));
      while(stepKillNear(minLine)) {
         count++;
      }
      if(count > 0) {
         DMath.trace("---- removed " + count + " points in " + glyphName);
//         System.out.println("---- removed " + count + " points in " + glyphName);
      }
   }

/**
 * The method... stepSplitLong
 * used by splitLongLines
 * @param longLine double
 * @return true if split
 */
   private boolean stepSplitLong(double longLine) {
      for(Cpath cp : (ArrayList <Cpath>) this) {
         for(int i = 0; i < cp.size() - 1; i++) {
            Cpoint a = (Cpoint) cp.get(i);
            Cpoint b = (Cpoint) cp.get(i + 1);
            if(a.distance(b) > longLine) {
// random coeff, range: 0.4-0.6
               double coeff = 0.4 + ((Math.random() + Math.random()) / 10);
               double x = a.x + coeff * (b.x - a.x);
               double y = a.y + coeff * (b.y - a.y);
               Cpoint p = new Cpoint(x, y, cp);
               cp.addBaseAPB(a, p, b);
               return true;
            }
         }
      }
      return false;
   }

/**
 * The method... splitLongLines
 * adds extra points to glyph
 * use: after char reading
 */
   private void splitLongLines() {
      int count = 0;
      Double longLine = Double.parseDouble(getBaseApp().getProperty("longLine"));
      while(stepSplitLong(longLine)) {
         count++;
      }
      if(count > 0) {
         DMath.trace("++++ added " + count + " points in " + glyphName);
//         System.out.println("++++ added " + count + " points in " + glyphName);
      }
   }

/**
 * The method... testOutput
 *not used
 */
   private void testOutput() {
      for(SMoto moto : (ArrayList <SMoto>) myDrome) {
         if(moto.eventDone()) {
            addNewLine(moto.start, moto.dir);
         }
         else {
            if(moto.eventLive()) {
               addNewLine(moto.start, moto.dir);
               addCrossPointGlyph(moto.dir.x, moto.dir.y, 0.1);
            }
         }
      }
   }

/**
 * The method... simplify
 * eliminates unuseful aligned points
 * use: <CODE>while(simplify());</CODE>
 * as last cleanup
 * @return boolean
 */
   private boolean simplify() {
      for(Cpath cp : (ArrayList <Cpath>) this) {
         for(int i = 0; i < cp.size() - 2; i++) {
            Cpoint a = (Cpoint) cp.get(i);
            Cpoint p = (Cpoint) cp.get(i + 1);
            Cpoint b = (Cpoint) cp.get(i + 2);
            if(Cpoint.isInSegment(a, b, p)) {
               cp.remove(i + 1);
               return true;
            }
         }
      }
      return false;
   }

/**
 * The method... adjustLast
 * makes the first and last points the same
 */
   private void adjustLast() {
      for(Cpath cp : (ArrayList <Cpath>) this) {
         if(cp.isBase()) {
            Cpoint pA = (Cpoint) cp.get(0);
            Cpoint pZ = (Cpoint) cp.get(cp.size() - 1);
            pA.x = pZ.x;
            pA.y = pZ.y;
         }
      }
   }

/**
 * ================================ EXPLODE: main CHAR Processing
 * The method... explode
 */
   public void explode() {
//    System.out.println("in explode");
      doMotoEvolution();
      String SKoutput = getBaseApp().getProperty("SKoutput");
//=======  final cleanup
      if(!SKoutput.equals("TEST0")) {

         myDrome.doBorderCollisions();
         myDrome.doSimplifyFrontals();

// cuts all long segments
         Cpoint x = null;
         do {
           x = myDrome.findMultiPoint();
            myDrome.cutAt(x);
         }

         while(x != null);

         myDrome.finalClean2parall();
// find last intersections
         myDrome.doneMotos();
// conditonal cleanup
         myDrome.killDangling();

      }
// ===== generating output
      double ShrinkFactor = Double.parseDouble(getBaseApp().getProperty("ShrinkFactor").trim());
      for(SMoto motou : (ArrayList <SMoto>) myDrome) {
         if(SKoutput.equals("TEST") || SKoutput.equals("TEST0")) {
            if(!motou.eventDead()) {
               if ( motou.end == null){
//                System.out.println(" ERROR: END null in " + motou);
               } else
               addNewLine(motou.start, motou.end);
            }
         }
         if(SKoutput.equals("LINE")) {
            if(motou.start != null && motou.end != null && motou.start.isBase()) {
               motou.start.x = motou.end.x;
               motou.start.y = motou.end.y;
            }
         }
         if(SKoutput.equals("SHRINK")) {
            if(motou.start != null && motou.end != null && motou.start.isBase()) {
               motou.start.x = motou.end.x + ShrinkFactor * (motou.start.x - motou.end.x);
               motou.start.y = motou.end.y + ShrinkFactor * (motou.start.y - motou.end.y);
            }
         }
      }
// very last cleanup
      adjustLast();
   }


/**
 * The method... doMotoEvolution
 */

   public void doMotoEvolution() {
// TODO try special
      while(simplify()) { }
 //     DMath.trace = true; //(code == 103);
  //    System.out.println("=== processing "+ glyphName);
      myDrome = new SDrome(this);
      myDrome.popolateDrome();
 // for step 1 - only near collisions:
      myDrome.doBorderCollisions();
      myDrome.doCollisions(1);
      myDrome.doProcessIntersections();
 //
      myDrome.doBorderCollisions();
      myDrome.doSimplifyFrontals();
//
      myDrome.doBorderCollisions();
// upcase: 65..90;  lowcase: 97..122;  numbers: 48..57 (
 //    if (((code <48 )||(code > 57 && code <65)||(code > 90 && code <97)||(code > 122)) && (getCharPointCount()< 40))

 // special cleanup for #
     if (code == 35 )
           myDrome.cleanMulti();
    //      intercepts simple glyphs like * | /, now done
           if(myDrome.countIntersectionMoto() < 1 && myDrome.countBorderMoto() < 1) {
    // done processes
               System.out.println("==== done 1 step for " + glyphName );
               return;
               }
     //   if(true) return;
 // for step 1 - only 1 1 collisions:

      SMoto dothis = null;
      SMoto startmoto =  null;
      int  count = 0;
      dothis = null;
      startmoto =  null;
      count = 0;
// loop deep 1
      do {
         if (dothis == null) {
         if( count < 20)
            startmoto = dothis =  myDrome.doStartCollisions(2);  // old 2 step
        if (dothis == null){
               startmoto = dothis =    myDrome.doRoundStart(count);
              }

            DMath.trace("== doStartCollisions  "  +startmoto);
            } else {
                 DMath.trace("doMotoEvolution:  loop for " + dothis);
                 dothis =  myDrome.doMultiCollisions(dothis, 1,1);  // old 1,1
                 myDrome.doProcessIntersection(dothis);
                 myDrome.doBorderCollisions();
                 dothis =  myDrome.doNextLinear(dothis);
           }
           if (count++ > 40) break;
        } while (startmoto != null);

   //
      myDrome.doSimplifyFrontals();
  //    myDrome.cleanMulti();

      myDrome.doBorderCollisions();

      if(myDrome.countIntersectionMoto() < 1 && myDrome.countBorderMoto() < 1) {
// done processes
         System.out.println("==== done 2 step for " + glyphName );
         return;
       }
// if(true) return;
      myDrome.doCollisions(100);
      myDrome.doProcessIntersections();
      myDrome.doBorderCollisions();
      dothis = null;

  //    startmoto =  null;
      count = 0;
// loop deep 3
   // System.out.println("=== processing loop 3");

      do {
           if (dothis == null) {
            if (count < 20){

               startmoto = dothis =  myDrome.doStartCollisions(3);  // old 3 step
            }
            if (dothis == null){
                startmoto = dothis =    myDrome.doRoundStart(count);
            }

            DMath.trace("== doStartCollisions  "  +startmoto);
            } else {

                 DMath.trace("doMotoEvolution:  loop for " + dothis);
                 dothis =  myDrome.doMultiCollisions(dothis, 100, 100);
                 myDrome.doProcessIntersection(dothis);
                 myDrome.doBorderCollisions();
                 dothis =  myDrome.doNextLinear(dothis);

         }
           if (count++ > 40) break;
        } while (startmoto != null);
       myDrome.doBorderCollisions();
      if(myDrome.countIntersectionMoto() < 1 && myDrome.countBorderMoto() < 1) {
// done processes
           System.out.println("==== done 3 step for " + glyphName );
           return;
       }
 //     System.out.println("step3 === inters.: " + myDrome.countIntersectionMoto() + ", border: " + myDrome.countBorderMoto());

   System.out.println("==== done timeout for " + glyphName );
 }


}
