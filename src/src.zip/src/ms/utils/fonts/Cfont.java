//@source: D:\User\Documents\progetti2016\stickfonts\font_filter\src\ms\ utils\fonts\Cfont.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
// package and import
package ms.utils.fonts;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintStream;
import java.io.IOException;
import ms.utils.aarray.baseapp.AABaseAppl;
import ms.utils.fonts.Cpoint;
import ms.utils.fonts.Cpath;
import ms.utils.fonts.Cchar;

/**
 * This Class is global singleton for a font, a list of char
 * <br />Source build by JStruct [charset UTF-8].<br />
 * @author (c)20016 M. Sillano (marco.sillano@gmail.com)
 * @version 1.00.00  build 3  (2016.01.15-09:09:40)
 */
public class Cfont <E>
extends ArrayList<E> {
   private static AABaseAppl aaBase;

   /* class global variables */
   private double minX;
   private double maxX;
   private double minY;
   private double maxY;
   private String name;
   // SVG constants
   public static int units_per_em = 8192;
   public static int ascent = 6520;
   public static int descent = -1480;
   public static int dist = 400;
   public static double svg_chrScale = 4000 / 18;
   // quadratic maps
   public double[] finalQM = {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1};
   public double[] testQM = {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1};
   private double Qscale;

/**
 * Method Cfont
 */
   public Cfont() {
      super();
   }

/**
 * The constructor Cfont
 * @param n int
 */
   public Cfont(int n, AABaseAppl app) {
      super(n);
      aaBase = app;
   }
//  ==================== setters & getters

 public AABaseAppl getBaseApp(){
    return aaBase;
 }

/**
 * setters & getters
 * @return double
 */
   public double getMinX() {
      return minX;
   }

/**
 * The method... getMaxX
 * @return double
 */
   public double getMaxX() {
      return maxX;
   }

/**
 * The method... getMinY
 * @return double
 */
   public double getMinY() {
      return minY;
   }

/**
 * The method... getMaxY
 * @return double
 */
   public double getMaxY() {
      return maxY;
   }

/**
 * The method... setFontName
 * @param name String
 */
   public void setFontName(String name) {
      this.name = name;
   }
/**
 * The method...getFontName
 * @return name String
 */
   public String getFontName() {
     return name;
   }


public int getSKstart(){
    return Integer.parseInt(aaBase.getProperty("SKstart").trim());
}

public int getSKend(){
    return Integer.parseInt(aaBase.getProperty("SKend").trim());
}

/**
 * TODO: Add your code here
 * @param n int
 * @return Cchar
 */
   public Cchar getCharFronCode(int code) {
      for(Cchar ch : (ArrayList <Cchar>) this) {
         if(ch.getCode() == code) {
            return ch;
         }
      }
      return null;
   }

/**
 * The method... getCharFromName
 * @param glyphName String
 * @return Cchar
 */
   public Cchar getCharFromName(String glyphName) {
      for(Cchar ch : (ArrayList <Cchar>) this) {
         if(ch.getName().equals(glyphName)) {
            return ch;
         }
      }
      return null;
   }

//  --------- utilities: access to   Adobe Glyph List For New Fonts
//  see https://github.com/adobe-type-tools/agl-aglfn/

/**
 * lookup in aglfn file
 * From aCode (Unicode) gets the glyphName like "A", "space",...
 * If achar != null, updates glyphName and long characterName in achar.
 * @return String  getGlyphName
 * @param acode int
 */
   public static String getGlyphName(int acode, Cchar achar) {
      String r = null;
      try  (final BufferedReader ffin = new BufferedReader(new FileReader("aglfn.txt")))
       {
         String iStr = "";
         while(iStr != null) {
            iStr = ffin.readLine();
            if((iStr != null) && (iStr.length() > 4)) {
               if(iStr.charAt(0) != '#') {
                  String[] parts = iStr.split(";");
                  if((achar != null) && (achar.getCode() == Integer.parseInt(parts[0].trim(), 16))) {
                     r = achar.glyphName = parts[1].trim();
                     achar.characterName = parts[2].trim();
                     achar.unicode = "&#x" + parts[0].trim().toLowerCase() + ";";
                     break;
                  }
                  if((achar == null) && (acode == Integer.parseInt(parts[0].trim(), 16))) {
                     r = parts[1].trim();
                     break;
                  }
               }
            }
         }
      }
      catch (Exception e) {
         System.err.println("ERROR");
         e.printStackTrace();
         System.exit(AABaseAppl.PROCESS_FAILURE);
      }
      return r;
   }

/**
 * lookup inverse of getGlyphName in aglfn file
 * From glyphName  like "A", "space",... gets the code (Unicode)
 * @return int the code
 */
   public static int getCode(String glyphName) {
      try  (final BufferedReader ffin = new BufferedReader(new FileReader("aglfn.txt")))
        {
         String iStr = "";
         while(iStr != null) {
            iStr = ffin.readLine();
            if((iStr != null) && (iStr.length() > 4)) {
               if(iStr.charAt(0) != '#') {
                  String[] parts = iStr.split(";");
                  if(glyphName.equals(parts[1].trim())) {
                     return Integer.parseInt(parts[0].trim(), 16);
                  }
               }
            }
         }
      }
      catch (Exception e) {
         System.err.println("ERROR");
         e.printStackTrace();
         System.exit(AABaseAppl.PROCESS_FAILURE);
      }
      return - 1;
   }

 public void jseval(String xexp, String yexp){
         for(Cchar ch : (ArrayList <Cchar>) this) {
            if (ch.getCode() >= getSKstart() && ch.getCode() <= getSKend()){
                System.out.println("==== eval char "+ch.glyphName);
                ch.jseval(xexp, yexp);
             }
         }
 }



//  ========================== building cChar stuff




/**
 * The method... setMinMax
 */
   public void setMinMax() {
      minX = 10000;
      maxX = - 10000;
      minY = 10000;
      maxY = - 10000;
      for(Cchar ch : (ArrayList <Cchar>) this) {
         if(ch.getMinX() < minX) {
            minX = ch.getMinX();
         }
         if(ch.getMaxX() > maxX) {
            maxX = ch.getMaxX();
         }
         if(ch.getMinY() < minY) {
            minY = ch.getMinY();
         }
         if(ch.getMaxY() > maxY) {
            maxY = ch.getMaxY();
         }
      }
   }

/**
 * Read a CHR file and set structures.
 * @param afin BufferedReader, input file
 * @param fontName String
 */
   public void addChars(BufferedReader afin, String fontName) throws IOException {
      String iStr = "";
      while(iStr != null) {
         iStr = afin.readLine();
         if(iStr != null) {
// extended
// accepts:  CHR_XX YY;
// and also: CHR_XXXX YY;   (unicode 0000-ffff)
try{
            int x = iStr.indexOf(' ');

            String n = iStr.substring(4, x).trim();
            Integer charcode = Integer.parseInt(n, 16);
            String s = iStr.substring(x + 1).trim();
            if(s.equals("0")) {
               this.add((E) new Cchar(charcode, null, this));
            }
            else {
               this.add((E) new Cchar(charcode, s, this));
            }
} catch (Exception e) {
    if (this.isEmpty())
    System.out.println("ERROR malformed definition in CHR input file");
    else
    System.out.println("ERROR malformed definition in CHR input file after char: "+((Cchar)this.get(this.size()-1)).glyphName);

}
         }
      }
      name = fontName;
      setMinMax();
   }

/**
 * ======================= biquadratic stuff
 * @param coeff double[]
 * @param x double
 * @param y double
 * @return double
 */
   public double xQuadratic(double[] coeff, double x, double y) {
      return((coeff[0] + coeff[1] * x * x + coeff[2] * x * y + coeff[3] * y * y + coeff[4] * x + coeff[5] * y) * Qscale);
   }

/**
 * The method... yQuadratic
 * @param coeff double[]
 * @param x double
 * @param y double
 * @return double
 */
   public double yQuadratic(double[] coeff, double x, double y) {
      return((coeff[6] + coeff[7] * x * x + coeff[8] * x * y + coeff[9] * y * y + coeff[10] * x + coeff[11] * y) * Qscale);
   }

/**
 * The method... setQCoeff
 * @param coeff double[]
 * @param setup String
 */
   public void setQCoeff(double[] coeff, String setup) {
      String[] sCoeff = setup.split(";");
      for(int i = 0; i < 12; i++) {
         coeff[i] = Double.parseDouble(sCoeff[i].trim());
      }
   }

/**
 * compensation for big values of coeffs
 */
   public void setQScale(double[] coeff) {
      Qscale = 1;
      double scale = 0;
      scale += 30 / xQuadratic(coeff, 30, 30);
      scale += 30 / yQuadratic(coeff, 30, 30);
      Qscale = scale / 2;
   }
// ===============  explode stuff

public void explode(){
     for(Cchar ch : (ArrayList <Cchar>) this) {
        if (ch.getCode() >= getSKstart() && ch.getCode() <= getSKend())
                    ch.explode();
     }
}
/**
 * ****************  CHR and SVG output stuff
 * @param aout PrintStream
 */
   public void pre_outputSVG(PrintStream aout) {
      aout.println("<?xml version=\"1.0\" standalone=\"no\"?>");
      aout.println("<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">");
      aout.println("<svg xmlns=\"http://www.w3.org/2000/svg\">");
      aout.println("<metadata>Modified by FontFilter</metadata>");
      aout.println("<defs>");
      aout.println("<font id=\"" + name + "\" horiz-adv-x=\"0\" >");
      aout.println("<font-face units-per-em=\"8192\" ascent=\"6520\" descent=\"-1672\" />");
//   aout.println("<glyph horiz-adv-x=\"3000\" />");
// first 4 standard TTF fonts
      aout.println("<missing-glyph horiz-adv-x=\"2000\" d=\"M0,0v4000h2000v-4000z\" />");
//    aout.println("<glyph glyph-name=\"uni0000\" />");
//    aout.println("<glyph glyph-name=\"space\" unicode=\" \" horiz-adv-x=\"1024\"/>");
//     aout.println("<glyph glyph-name=\"space\" unicode=\"&#xa0;\" horiz-adv-x=\"1024\" />");
      aout.println("<glyph glyph-name=\"uni000D\" unicode=\"&#xd;\" />");
   }

/**
 * The method... post_outputSVG
 * @param aout PrintStream
 */
   public void post_outputSVG(PrintStream aout) {
//aout.println("<glyph horiz-adv-x=\"3000\" />");
      aout.println("</font>");
      aout.println("</defs></svg>");
   }

/**
 * The method... dumpCHR
 * @param aout PrintStream
 */

   public void dumpCHR(PrintStream aout, int start, int end) {
     setQScale(finalQM);
     for(Cchar ch : (ArrayList <Cchar>) this)
        if (ch.getCode() >= start && ch.getCode() <= end){
         aout.println(ch.dumpCHR());
      }
   }

/**
 * The method... dumpSVG
 * @param aout PrintStream
 */

   public void dumpSVG(PrintStream aout, int start, int end) {
      setQScale(finalQM);
      pre_outputSVG(aout);
      for(Cchar ch : (ArrayList <Cchar>) this)
        if (ch.getCode() >= start && ch.getCode() <= end){
           aout.println(ch.dumpSVG(svg_chrScale));
      }
      post_outputSVG(aout);
   }

}
