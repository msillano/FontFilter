//@source: D:\User\Documents\progetti2016\stickfonts\font_filter\src\ms\ utils\fonts\Cpath.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
// package and import
package ms.utils.fonts;

import java.util.ArrayList;
import ms.utils.fonts.Cpoint;
import ms.utils.fonts.Cchar;
import ms.utils.fonts.Cfont;

 enum pathStatus {
   BASE,
   NEW,
   HIDDEN,
   NONE
 }

/**
 * Cpath, an ArratList of Cpoints
 * <br />Source build by JStruct [charset UTF-8].<br />
 * @version 1.00.00  build 6  (2016.01.21-18:59:40)
 *@author Sillano
 */
public class Cpath <E>
extends ArrayList<E> {

   /* class global variables */
   private pathStatus status = pathStatus.BASE;
   private Cchar achr;
 // ============================================ SETTER/GETTER


public int addBaseAPB(Cpoint a, Cpoint p, Cpoint b){
    int posA= indexOf(a);
    int posB= indexOf(b);
    p.setBase();
    if (posA < posB){
        add(posA  + 1,(E) p);
        return posA;
    }
    else{
        add(posB + 1, (E) p);
        return posB;
    }
}

/**
 * The method... getName
 * @return String
 */
   public Cchar getChar() {
      return achr;
   }

/**
 * The method... getName
 * @return String
 */
   public Cfont myFont() {
      return getChar().myFont();
   }

/**
 * The method... isBase
 * @return boolean
 */
   public boolean isBase() {
      return status == pathStatus.BASE;
   }

/**
 * The method... isVisuble
 * @return boolean
 */
   public boolean isVisible() {
      return !(status == pathStatus.HIDDEN);
   }

/**
 * The method... setHidden
 */
   public void setHidden() {
      status = pathStatus.HIDDEN;
   }
// ====================== CONSTRUCTORS
/**
 * Constructor Cpath, from a String, reading input CHR file
 *
 * @param p String
 * @param achr Cchar
 */
   public Cpath(String p, Cchar achr) {
      super();
      status = pathStatus.BASE;
      this.achr = achr;
      String[] nodes = p.split(" ");
      for(String point : nodes) {
         this.add((E) new Cpoint(point.trim(), this));
      }
   }

/**
 * The constructor Cpath
 * @param achr Cchar
 */
   public Cpath(Cchar achr) {
      super();
      status = pathStatus.NEW;
      this.achr = achr;
   }

// ============================= public

/**
 * The method... dumpCHR
 * @return String
 * @param coeff double[]
 */
   public String dumpCHR(double[] coeff) {
      String s = "";
      for(int i = 0; i < this.size(); i++) {
         s += (s == "" ? "" : " ") + transX(i, coeff) + "," + transY(i, coeff);
      }
      return s;
   }

/**
 * The method... dumpSVG
 * @return String
 * @param scale double
 * @param coeff double[]
 */
   public String dumpSVG(double scale, double[] coeff) {
      String s = "M ";
      s += Math.round(transX(0, coeff) * scale) + " " + Math.round(transY(0, coeff) * scale) + " L ";
      for(int i = 1; i < this.size() - 1; i++) {
         s += Math.round(transX(i, coeff) * scale) + " " + Math.round(transY(i, coeff) * scale) + " ";
      }
      return s + "z";
   }


// ====================== private
/**
 * The method... transX
 * @param i int
 * @param coeff double[]
 * @return double
 */

  private double transX(int i, double[] coeff) {
      double x = ((Cpoint) this.get(i)).x;
      double y = ((Cpoint) this.get(i)).y;
      return myFont().xQuadratic(coeff, x, y);
   }

/**
 * The method... transY
 * @param i int
 * @param coeff double[]
 * @return double
 */
   private double transY(int i, double[] coeff) {
      double x = ((Cpoint) this.get(i)).x;
      double y = ((Cpoint) this.get(i)).y;
      return myFont().yQuadratic(coeff, x, y);
   }

}
