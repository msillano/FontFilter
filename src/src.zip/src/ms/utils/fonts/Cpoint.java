//
//
//
//@source: D:\User\Documents\progetti2016\stickfonts\font_filter\src\ms\ utils\fonts\Cpoint.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
// package and import
package ms.utils.fonts;

import java.util.ArrayList;
import ms.utils.DMath;
import ms.utils.fonts.Cpath;
import ms.utils.fonts.Cchar;
import ms.utils.fonts.Cpoint;
import ms.utils.fonts.skeleton.SMoto;
import ms.utils.fonts.skeleton.SDrome;

/**
 * status of a char-point
 * <br />Source build by JStruct [charset UTF-8].<br />
 *@version 1.00.00  build 5 2016.01.21
 *@author Sillano
 */

enum pointStatus {
   BASE,
   NONE,
   NEW,
   HIDDEN
}

/**
 * Defines a point having double usage:
 * As generic point (x, y) fot geometrical data elaboration (status == NONE)
 * As a char-point in a char definition (status == BASE|NEW|GHOST)
 * BASE: original point
 * NEW: new point
 * GHOST: do not put in out
 */
public class Cpoint {
   /* class global variables */
   public double x;
   public double y;
   // the path where this char-point is
   private Cpath path;
   // the status of this char-point, to skip some old char-points
   private pointStatus pointStatus;


 /**
 *======================================  static math/geom stuff for points
 * is AB parallel to CD?
 * @param a Cpoint
 * @param b Cpoint
 * @param c Cpoint
 * @param d Cpoint
 * @return boolean, true if parallel
 */
   public static boolean isParallel(Cpoint a, Cpoint b, Cpoint c, Cpoint d) {
      return DMath.isParallel(a.x, a.y, b.x, b.y, c.x, c.y, d.x, d.y);
   }

   public static boolean quasiEqual(Cpoint a, Cpoint p) {
      return DMath.quasiEqual(a.x, p.x) && DMath.quasiEqual(a.y, p.y);
   }


   public static double triangleSurface(Cpoint a, Cpoint b, Cpoint c) {
      return DMath.triangleSurface(a.x, a.y, b.x, b.y, c.x, c.y);
   }

    public static double distance(Cpoint a, Cpoint b) {
      return DMath.distance(a.x, a.y, b.x, b.y);
   }

/**
 * is AB in same line of CD?
 * use it after parallel test ab//cd
 * @param a Cpoint
 * @param b Cpoint
 * @param c Cpoint
 * @param d Cpoint
 * @return boolean
 */
   public static boolean isCollinear(Cpoint a, Cpoint b, Cpoint c, Cpoint d) {

        double base = distance(a,b);
        double dist1 = Math.abs( (triangleSurface(a, b, c)*2)/ base);
        double dist2 = Math.abs( (triangleSurface(a, b, d)*2)/ base);
 //   return isParallel(a,b,c,d) && isParallel(a,c,b,d) &&  isParallel(a,d,c,b) ; // strict
      return  dist2 < DMath.attractRadius/2 && dist1 < DMath.attractRadius/2 ;

  //  return isParallel(a,c,b,d) &&  isParallel(a,d,c,b);
    }


public static Cpoint hortoPoint(Cpoint a, Cpoint b, Cpoint p){
    if(a.quasiEqual(b)){
         throw new UnknownError(" Points A, B not a segment");
         }
    if (DMath.quasiEqual(a.x,b.x)){
       // special case, vertical
        return new Cpoint(p.x +1, p.y);
        }
      if (DMath.quasiEqual(a.y,b.y)){
       // special case, horizontal
        return new Cpoint(p.x, p.y + 1);
        }
  double m = (b.y - a.y)/(b.x - a.x);
  return new Cpoint(p.x +1, p.y - 1/m);
}
/**
 * get the intersection point P of 2 lines/segments
 *  solution system using Kramer:
 *  h*(Ax-Bx) + k*(Dx-Cx) = (Ax-Cx)
 *  h*(Ay-By) + k*(Dy-Cy) = (Ay-Cy)
 * then
 *  Px = Ax +h*(Bx-Ax)  or  Px = Cx +k*(Dx-Cx)
 *  Py = Ay +h*(By-Ay)  or  Py = Cy +k*(Dy-Cy)
 * conditions
 *   inAB <=>  0<=h<=1
 *   inCD <=>  0<=k<=1
 *   positive  <=>  h >=0 & k >=0
 * return null if parallel
 * @param a Cpoint
 * @param b Cpoint
 * @param d Cpoint
 * @return Cpoint
 */
   public static Cpoint getIntersection(Cpoint a, Cpoint b, Cpoint c, Cpoint d, boolean inAB, boolean inCD, boolean positive) {
      if( a== null || b==null || c==null || d== null)  return null;
      if(isParallel(a, b, c, d)){
/*          if (isCollinear(a, b, c, d)) {
                if ( inAB && isInSegment(a, b,  c)) return c;
                if ( inAB && isInSegment(a, b,  d)) return d;
                if ( inCD && isInSegment(c, d,  a)) return a;
                if ( inCD && isInSegment(c, d,  b)) return b;
                return new Cpoint((a.x+b.x+c.x+d.x)/4, (a.y+b.y+c.y+d.y)/4);
           }
*/
//  DMath.tracelocal("point_getIntersection: NO intersection (parallel) ");
         return null;
         }
      double ABx = a.x - b.x;
      double DCx = d.x - c.x;
      double ACx = a.x - c.x;
      double ABy = a.y - b.y;
      double DCy = d.y - c.y;
      double ACy = a.y - c.y;
        double delta = DMath.det(ABx, DCx, ABy, DCy);
      if(DMath.quasiEqual(delta, 0)) {
         throw new UnknownError(" Delta equal 0");
      }
      double deltah = DMath.det(ACx, DCx, ACy, DCy);
      double deltak = DMath.det(ABx, ACx, ABy, ACy);
      double h = deltah / delta;
      double k = deltak / delta;
      if (DMath.quasiEqual(h, 0))  h= 0;
      if (DMath.quasiEqual(k, 0))  k= 0;
      if (DMath.quasiEqual(h, 1))  h= 1;
      if (DMath.quasiEqual(k, 1))  k= 1;
          if(inAB && ( h < 0 || h > 1)) {
// DMath.tracelocal("point_getIntersection: NO inAB, h = " + h);
              return null;
          }
          if(inCD && (k < 0 || k > 1)) {
// DMath.tracelocal("point_getIntersection: NO inCD, k = " + k);
            return null;
          }
          if(positive && ( h < 0 || k < 0 )) {
//  DMath.tracelocal("point_getIntersection: NO positive, h = " + h + " k = " + k);
            return null;
          }
      return new Cpoint(((a.x - h * ABx)+(c.x + k * DCx))/2,(( a.y - h * ABy) +(c.y + k * DCy))/2);
   }

/**
 * done the angle ABC finds the intrsection of B angle bisector and AC segment
 * @param a Cpoint
 * @param b Cpoint
 * @param c Cpoint
 * @return Cpoint
 */
   public static Cpoint pointBisector(Cpoint a, Cpoint b, Cpoint c) {
// Uses the fact that the lengths of the parts of the split segment
// are proportional to the lengths of the adjacent triangle sides
// modified from com.vividsolutions.jts.geom.Triangle
      Cpoint d = null;
// bad cases
      if(a.quasiEqual(b) || b.quasiEqual(c) ) {
 //         throw new UnknownError(" Points A, B, C not a triangle");
      }
// special case: parallel and equal
    //   if( a.quasiEqual(c)){
     if( a.distance(c) < DMath.attractRadius/2){
       DMath.tracelocal("pointBisector- case 1");
       return c;
      }
// special case: a,b,c collinear: returns a parallel/hortogonal point
      if(isParallel(a, b, b, c)) {
//         if (isInSegment(a,c,b)) { // B in AC
      if (DMath.quasiEqual(a.distance(c),a.distance(b) + b.distance(c))) {
// hortogonal
               DMath.tracelocal("pointBisector- case 2, AC = " + a.distance(c));
               DMath.tracelocal(" AB = " + a.distance(b) + " BC = " + b.distance(c));
                return  hortoPoint(a,c,b);
             }
         else{
// parallel
               DMath.tracelocal("pointBisector- case 3");
               return new Cpoint((a.x+c.x)/2,(a.y+c.y)/2);
         }
      }

  // general case
      double len0 = b.distance(a);
      double len2 = b.distance(c);
//   double lenSeg = a.distance(c);
      double frac = len0 / (len0 + len2);
      Cpoint p = new Cpoint(a.x + frac * (c.x - a.x), a.y + frac * (c.y - a.y));
      // quasi-parallel
      if (DMath.quasiEqual(b.distance(p), 0)) {
            if (isInSegment(a,c,b)) { // B in AC
// hortogonal
            DMath.tracelocal("pointBisector- case 2-bis");
             return  hortoPoint(a,c,b);
            }
         else{

// parallel
             DMath.tracelocal("pointBisector- case 3-bis");
             return new Cpoint((a.x+c.x)/2,(a.y+c.y)/2);
             }
      }
      DMath.tracelocal("pointBisector- general");
      return p ;
   }


public Cpoint getLeftPoint(){
    if (this.path== null) return null;
    int pos = this.path.indexOf(this);
    pos = (pos == path.size()-1)?1:pos+1;
    if (pos < 0) return null;
    return (Cpoint) this.path.get(pos);
 }

public Cpoint getRightPoint(){
    if (this.path== null) return null;
     int pos = this.path.indexOf(this);
    if (pos < 0) return null;
    pos = (pos == 0)? path.size()-2:pos-1;
    return (Cpoint) this.path.get(pos);
 }

  public boolean isAligned(Cpoint a, Cpoint b) {
     double base = distance(a,b);
     double dist1 = (triangleSurface(a, b, this)*2)/ base;
     return dist1 < DMath.precision;
   }



/**
 * The method... isLeft
 * sign((Bx - Ax) * (Y - Ay) - (By - Ay) * (X - Ax)) 0, -1, +1
 *
 * @param a Cpoint
 * @param b Cpoint
 * @param x double
 * @param y double
 * @return boolean
 */
   public static boolean isLeft(Cpoint a, Cpoint b,  Cpoint c) {
      return((b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)) > 0;
   }

   /**
    * A, B, P allineati
    *Px = Ax + tx(Bx-Ax) => 0<=tx<=1
    *
    */
    public static boolean isInSegment(Cpoint a, Cpoint b,  Cpoint p){
        /*
        if (DMath.quasiEqual(b.x,a.x)){
// special, horizontal
           DMath.tracelocal("isInSegment-special");
           return !(((p.y > a.y)&& (p.y > b.y))|| ((p.y < a.y)&& (p.y < b.y)));
        }
        */
/*
        double tx = (p.x -a.x)/(b.x-a.x);
         DMath.tracelocal("inSeg-standard t = " +tx);
        return(tx >= 0 && tx <= 1);
*/
 //   DMath.tracelocal("isInSegment-standard ");
    return (DMath.quasiEqual(b.distance(a),a.distance(p) + p.distance(b)));
    }
/**
 *  Teorema di Carnot, che ci permette di trovare un angolo dai tre lati:
 * cos (a) = (B^2+C^2 - A^2)/(2BC).
*/
   public static double cosA (Cpoint pB, Cpoint pA, Cpoint pC ){
     // cos (A) = (b^2+c^2 - a^2)/(2*b*c).
    double a =  pB.distance(pC);   // BC
    double b =  pA.distance(pC);   // AC
    double c =  pA.distance(pB);   // AB
    return (b*b + c*c - a*a)/ 2*b*c;
   }
// a -> s, b -> new
  public static Cpoint   translateSegment(Cpoint a, Cpoint b,  Cpoint s) {
      return new Cpoint(b.x+(s.x - a.x), b.y+(s.y-a.y));
  }

/**
 *============================================  this point geom stuff
 * distance from this
 * @return double
 */
   public double distance(Cpoint p) {
      if (p == null){
         throw new UnknownError(" Null point distance");
      }
      return DMath.distance(x, y, p.x, p.y);
   }

/**
 * quasiEqual to this
 * @param p Cpoint
 * @return boolean
 */
   public boolean quasiEqual(Cpoint p) {
      if (p == null){
         throw new UnknownError(" Null point quasiEqual");
      }
      return DMath.quasiEqual(this.x, p.x) && DMath.quasiEqual(this.y, p.y);
   }

   public  boolean isAttract(Cpoint p) {
     if (p == null){
         throw new UnknownError(" Null point isAttract");
      }
      return distance(p) < DMath.attractRadius;
   }

/**
 * quasiEqual to this
 * @param p Cpoint
 * @return boolean
 */
   public boolean near(Cpoint p) {
     if (p == null){
         throw new UnknownError(" Null point near");
      }
     return DMath.distance(x, y, p.x, p.y) < DMath.attractRadius;
   }


// ========================== setters/getters
/**
 * The method... getPath
 * @return Cpath
 */
   public Cpath getPath() {
      return path;
   }

/**
 * The method... myFont
 * @return Cfont
 */
   public Cfont myFont() {
      return path.getChar().myFont();
   }

/**
 * The method... isBase
 * @return pState
 */
   public boolean isBase() {
      return(pointStatus == pointStatus.BASE);
   }
  public void setBase() {
     pointStatus = pointStatus.BASE;
   }

/**
 * The method... isValid
 * @return boolean
 */
   public boolean isValid() {
      return(pointStatus == pointStatus.BASE | pointStatus == pointStatus.NEW);
   }

/**
 * The method... setHidden
 */
   public void setHidden() {
      pointStatus = pointStatus.HIDDEN;
   }

/**
 * The method... setVisible
 * @param path Cpath
 * @return Cpoint
 */
   public Cpoint setVisible(Cpath path) {
      this.path = path;
      pointStatus = pointStatus.NEW;
      return this;
   }

/**
 * Method cpoint
 * construuctor for a point (auxiliary)
 * @param x double
 * @param y double
 */
   public Cpoint(double x, double y) {
      super();
      this.path = null;
      this.x = x;
      this.y = y;
      pointStatus = pointStatus.NONE;
   }

/**
 * The constructor Cpoint, for new char points
 * @param x double
 * @param y double
 * @param path Cpath
 */
   public Cpoint(double x, double y, Cpath path) {
      super();
      this.path = path;
      this.x = x;
      this.y = y;
      pointStatus = pointStatus.NEW;
   }

/**
 * The constructor Cpoint from a string, reading input CHR file
 * @param p String
 * @param path Cpath
 */
   public Cpoint(String p, Cpath path) {
      super();
//     System.out.println(" p(" + p + ")");
      String[] points = p.split(",");
      this.path = path;
      this.x = Double.parseDouble(points[0]);
      this.y = Double.parseDouble(points[1]);
      pointStatus = pointStatus.BASE;
   }

/**
 * The method... toString
 * @return String
 */
   public String toString() {
      if(path == null) {
//          return "p??("+ x+", "+y+") ";
          return "p??() ";
      }
      else {
         int pos = path.getChar().charIndexOf(this);
//         return "#" + pos + "("+ x+", "+y+") ";
         return "#" + pos + "() ";
      }
   }

}
