//@source: D:\User\Documents\progetti2016\stickfonts\font_filter\src\ms\ utils\fonts\skeleton\SDrome.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
// package and import
package ms.utils.fonts.skeleton;

import java.util.ArrayList;
import java.util.Random;
import ms.utils.DMath;
import ms.utils.fonts.Cfont;
import ms.utils.fonts.Cchar;
import ms.utils.fonts.Cpath;
import ms.utils.fonts.Cpoint;


/**
 * SDrome
 * The moto container, a list of motos
 * <br />Source build by JStruct [charset UTF-8].<br />
 * @version 1.00.00  build 2  (2016.02.12-13:03:52)
 *@author Sillano
 */
public class SDrome <E>
extends ArrayList<E> {

   /* class global variables */
   Cchar myChar;
   int idCount = 0;
   public static SMoto lastMotoProcessed = null;

/**
 * The method... getNewId
 * @return int
 */
   public int getNewId() {
      return ++idCount;
   }

/**
 * The constructor SDrome
 * @param aChar Cchar
 */
   public SDrome(Cchar aChar) {
      super();
      myChar = aChar;
   }

/**
 * The method... addNewMoto
 * @param p1 Cpoint
 * @param p2 Cpoint
 * @param p3 Cpoint
 * @param aChar Cchar
 * @return SMoto
 */
   SMoto addNewMoto(Cpoint p1, Cpoint p2, Cpoint p3, Cchar aChar) {
      SMoto moto = new SMoto(p1, p2, p3, aChar);
      moto.deep = 1;
      moto.setId(getNewId());
      moto.myDrome = this;
      this.add((E) moto);
      return moto;
   }

/**
 * The method... addMoto
 * @param index int
 * @param moto SMoto
 */
   void addMoto(int index, SMoto moto) {
      if((moto.start == null) || (moto.dir == null) || (moto.motoL == null) || (moto.motoR == null)) {
         throw new UnknownError("!!!!!!!!!!!!!!!!!!!! New Moto attributes ERROR");
      }
      moto.deep = Math.max(moto.motoL.deep, moto.motoR.deep) + 1;
      moto.setId(getNewId());
      moto.myDrome = this;
      this.add(index, (E) moto);
   }

/**
 * The method... addMoto
 * @param moto SMoto
 */
   void addMoto(SMoto moto) {
      if((moto.start == null) || (moto.dir == null) || (moto.motoL == null) || (moto.motoR == null)) {
         throw new UnknownError("!!!!!!!!!!!!!!!!!!!! New Moto attributes ERROR");
      }
      moto.deep = Math.max(moto.motoL.deep, moto.motoR.deep) + 1;
      moto.setId(getNewId());
      moto.myDrome = this;
      this.add((E) moto);
   }

/**
 * The method... splitMoto
 * @param moto1 SMoto
 * @param sp Cpoint
 * @return SMoto
 */
   public SMoto splitBorderMoto(SMoto moto1, Cpoint sp) {
      DMath.trace("ENTER in SPLITBorderMoTO for "+ moto1);
      Cpoint p1 = moto1.border1;
      Cpath path = p1.getPath();
      Cpoint p2 = new   Cpoint(moto1.borderP.x, moto1.borderP.y, path);
      Cpoint p3 = moto1.border2;
      if (p1 == null || p2==null||p3==null||path == null){
//        System.out.println("ERRORE SPLIT "+ moto1);
        return null;
      }
      moto1.end = sp;
      int pos = path.addBaseAPB(p1, p2, p3);
      SMoto moto = new SMoto();
      moto.start = (Cpoint) path.get(pos+1);
      moto.end = sp;
      moto.myChar = moto1.myChar;
      moto.deep = 1;
      moto.dir = sp;
      moto.pl = (Cpoint) path.get(pos+2);
      moto.pr = (Cpoint) path.get(pos);
      moto.setId(getNewId());
      moto.myDrome = this;
      moto.setNew();
      this.add((E) moto);
      borderCollision(moto);
      return moto;
   }

  public SMoto splitAMoto(SMoto moto1, Cpoint sp) {
      DMath.trace("ENTER in SPLITAMoTO for "+ moto1);
      SMoto moto = new SMoto();
      moto.start = moto1.end;
      moto1.end = sp;
      moto1.time = moto1.start.distance(sp);
//
      moto.deep = moto1.deep;
      moto.myChar = moto1.myChar;
      moto.dir = sp;
      moto.setId(getNewId());
      moto.myDrome = this;
      moto.setNew();
      this.add((E) moto);
      borderCollision(moto);
// duplicates the original status
      moto.end = sp;
      moto.time =moto.start.distance(sp);
      moto.event = moto1.event;
      myChar.addCrossPointGlyph(sp.x, sp.y, 0.2);
      return moto;
   }

/**
 * The method... pointDone
 * @param p Cpoint
 * @return boolean
 */
   boolean pointDone(Cpoint p) {
      for(SMoto moto : (ArrayList <SMoto>) this) {
         if(moto.eventDone()) {
            if (!(moto.start == null)&&(p.quasiEqual(moto.start))) {
               return true;
            }
            if(!(moto.end == null)&&(p.quasiEqual(moto.end))) {
               return true;
            }
         }
      }
      return false;
   }

/**
 * The method... countBorderMoto
 * @return int
 */
   public int countBorderMoto() {
      int count = 0;
      for(SMoto moto : (ArrayList <SMoto>) this) {
         if(moto.eventBorder()) {
            count++;
         }
      }
      return count;
   }

/**
 * The method... countIntersectionMoto
 * @return int
 */
   public int countIntersectionMoto() {
      int count = 0;
      for(SMoto moto : (ArrayList <SMoto>) this) {
         if(moto.eventIntersection()) {
            count++;
         }
      }
      return count;
   }

/**
 * The method... borderCollision
 * @param moto SMoto
 */
   void borderCollision(SMoto moto) {
      if(moto.eventNew()) {
         moto.time = 100000;
         moto.end = null;
         for(Cpath cp : (ArrayList <Cpath>) myChar) {
            if(cp.isBase()) {
               for(int i = 0; i < cp.size() - 1; i++) {
                  Cpoint p1 = (Cpoint) cp.get(i);
                  Cpoint p2 = (Cpoint) cp.get(i + 1);
                  if(!(DMath.quasiEqual(p1.distance(moto.start), 0) || DMath.quasiEqual(p2.distance(moto.start), 0))) {
                     Cpoint px = Cpoint.getIntersection(moto.start, moto.dir, p1, p2, false, true, true);
                     if(px != null) {
                        double xdist = moto.start.distance(px);
                        if(xdist < moto.time) {
                           moto.time = xdist;
                           moto.borderP = moto.end = myChar.attraction(px);
                           moto.border1 = p1;
                           moto.border2 = p2;
                           moto.crash = null;
                           moto.event = MotoEvent.BORDER;
                        }
                     }
                  }
               }
            }
         }
         if(moto.end == null) {
            DMath.trace("ERROR NEW_BORDER moto " + moto + " D " + moto.start.distance(moto.dir));
            moto.event = MotoEvent.DEAD;
         }
      }
   }

/**
 * The method... popolateDrome
 */
   public void popolateDrome() {
      for(Cpath cp : (ArrayList <Cpath>) myChar) {
         if(cp.isBase()) {
            for(int i = 0; i < cp.size() - 2; i++) {
               addNewMoto((Cpoint) cp.get(i), (Cpoint) cp.get(i + 1), (Cpoint) cp.get(i + 2), myChar);
            }
            addNewMoto((Cpoint) cp.get(cp.size() - 2), (Cpoint) cp.get(cp.size() - 1), (Cpoint) cp.get(1), myChar);
         }
      }
   }

/**
 * The method... doBorderCollisions
 */
   public void doBorderCollisions() {
      for(SMoto moto : (ArrayList <SMoto>) this) {
         if(moto.eventNew()|| moto.borderP == null) {
            borderCollision(moto);
         }
         else {
            if(moto.eventProcessable() || moto.eventBadBorder()) {
               moto.restoreBorder();
            }
         }
      }
   }
/**
 *
 *
 **/
 public Cpoint findMultiPoint(){
     int count = 0;
     Cpoint crashPoint = null;
     for(int i = 0; i < this.size(); i++) {
         SMoto moto1 = (SMoto) this.get(i);
         if(!moto1.eventDead()) {
             count = 0;
            for(int j = 0; j < i; j++) {
               SMoto moto2 = (SMoto) this.get(j);
//               if(moto2.eventLive() || moto2.eventDone()) {
               if(!moto2.eventDead()) {
                Cpoint aPoint = Cpoint.getIntersection(moto1.start, moto1.end, moto2.start, moto2.end, true, true, true);
                   if(aPoint != null && !pointDone(aPoint) &&
                    !moto2.start.isAttract(aPoint)&&  !moto2.end.isAttract(aPoint) &&
                    !moto1.start.isAttract(aPoint)&&  !moto1.end.isAttract(aPoint)){
                    DMath.trace("found point " + moto1 + " vs "+ moto2);
                    crashPoint = aPoint;
                    count++;
                   }
              }
            }
         if (count > 2) {
 //          splitMoto(moto1, crashPoint)  ;
           myChar.addCrossPointGlyph(crashPoint.x, crashPoint.y, 0.2);
           DMath.trace(" MULTI FOUND + ");
           return crashPoint;
         }
     }
 }
 return null;
 }

 public void cleanMulti(){
    for(int i = 0; i < this.size(); i++) {
         SMoto moto1 = (SMoto) this.get(i);
         if (!moto1.eventBorder())continue;
         if (( moto1.start== null) ||( moto1.end == null)) continue;
         for(int j = 0; j < this.size(); j++) {
            if (j == i) continue;
            SMoto moto2 = (SMoto) this.get(j);
            if (!moto2.eventLive())continue;
            Cpoint p = moto2.start;
            Cpoint q =  moto2.end;
            if ((p== null)|| (q== null)) continue;
            if ( Cpoint.isInSegment(moto1.start, moto1.end, p) && (!!moto1.start.isAttract(p))){
               moto1.end = p;
               moto1.setDone();
               moto2.setDone();

//               System.out.println("cleanMulti on "+moto1+" vs start of "+moto2);
               continue;
            }
        if ( Cpoint.isInSegment(moto1.start, moto1.end, q) && (!!moto1.start.isAttract(q))){
               moto1.end = q;
               moto1.setDone();
               moto2.setDone();

               // System.out.println("cleanMulti on "+moto1+" vs end of "+moto2);
               continue;
            }
         if ((moto1.start.isAttract(p) && moto1.end.isAttract(q)) ||  (moto1.start.isAttract(q) && moto1.end.isAttract(p)))
             moto2.setDead();
             moto1.setDone();

         }
     }
 }
 public void cutAt(Cpoint aPoint){
      if (aPoint == null) return;
       for(int i = 0; i < this.size(); i++) {
         SMoto moto1 = (SMoto) this.get(i);
         if(!moto1.eventDead() && !moto1.start.isAttract(aPoint)&&  !moto1.end.isAttract(aPoint)){
            if (Cpoint.isInSegment (moto1.start, moto1.end, aPoint)){
                  splitAMoto(moto1, aPoint)  ;
            }
         }
      }
 }
/**
 * The method... finalClean2parall
 */
   public void finalClean2parall() {
      SMoto moto1 = null;
      SMoto moto2 = null;
      for(SMoto moto : (ArrayList <SMoto>) this) {
         if(moto.eventBorder()) {
            if(moto1 == null) {
               moto1 = moto;
            }
            else {
               if(moto2 == null) {
                  moto2 = moto;
               }
               else {
                  return;
               }
            }
         }
      }
      if(moto2 == null) {
         return;
      }
      myChar.addCrossPointGlyph(moto1.end.x, moto1.end.y, 0.2);
      myChar.addCrossPointGlyph(moto2.end.x, moto2.end.y, 0.2);
      if(Cpoint.isParallel(moto1.start, moto1.end, moto2.start, moto2.end)) {
         DMath.trace("finalClean2parall: found " + moto1 + " vs " + moto2);
         moto1.simplifyFrontal(moto2);
      }
   }

/**
 * The method... splitExtras
 */
   public void splitExtras() {
      int count = 0;
      Cpoint crashPoint = null;
      for(int i = 1; i < this.size(); i++) {
         SMoto moto1 = (SMoto) this.get(i);
         for(int j = 0; j < i; j++) {
            SMoto moto2 = (SMoto) this.get(j);
            if(moto1.start.quasiEqual(moto2.end) && moto1.end.quasiEqual(moto2.start)) {
               for(int k = 1; k < this.size(); k++) {
                  SMoto motox = (SMoto) this.get(k);
                  if((motox != moto1) && (motox != moto2)) {
                     crashPoint = Cpoint.getIntersection(moto1.start, moto1.end, motox.start, motox.end, true, true, true);
                  }
                  if(crashPoint != null) {
                     if(!(crashPoint.near(moto1.start) || crashPoint.near(moto1.end) || crashPoint.near(motox.start) || crashPoint.near(motox.end))) {
                        SMoto newm = splitAMoto(moto1, myChar.attraction(crashPoint));
                        if(moto2.getDeep() == 1) {
                           newm.end = newm.start;
                           newm.start = moto2.start;
                           newm.deep = 1;
                           newm.border1 = moto2.border1;
                           newm.border2 = moto2.border2;
                           newm.borderP = moto2.borderP;
                        }
                        DMath.trace("Splitted-1: " + moto1 + " > " + newm);
                        myChar.addSquarePointGlyph(crashPoint.x, crashPoint.y, 0.2);
                        break;
                     }
                  }
               }
               continue;
            }
            crashPoint = Cpoint.getIntersection(moto1.start, moto1.end, moto2.start, moto2.end, true, true, true);
            if(crashPoint != null) {
               if(!(crashPoint.near(moto1.start) || crashPoint.near(moto1.end) || crashPoint.near(moto2.start) || crashPoint.near(moto2.end))) {
                  splitAMoto(moto1, myChar.attraction(crashPoint));
                  splitAMoto(moto2, myChar.attraction(crashPoint));
                  DMath.trace("Splitted-2: " + moto1 + " and " + moto2);
               }
               else {
                  /* empty statement */
               }
            }
         }
      }
   }







/**
 * The method... doCollisions
 * @param level int
 * @return int
 */
   public int doCollisions(int distance) {
      int count = 0;
      for(int i = 0; i < this.size(); i++) {
         SMoto moto1 = (SMoto) this.get(i);
         if(moto1.eventLive()) {
            for(int j = 0; j < i; j++) {
               SMoto moto2 = (SMoto) this.get(j);
               if(moto2.eventLive() ||( moto2.eventDone() && ((moto2.next == null) || !moto2.next.eventDone())) ) {
  //             if(moto2.eventLive()) {
                  if(distance > 0) {
                     if(moto2.nodeDistance(moto1) <= distance) {
                        if(moto1.testSimpleIntersection(moto2)) {
                           DMath.trace("doCollisions_node_distance " + distance + " OK " + moto1 + " vs " + moto2);
                           count++;
                        }
                     }
                  }
                  else {
                     if((moto1.deep == 1) && (moto2.deep == 1)) {
                        if(moto1.testSimpleIntersection(moto2)) {
                           DMath.trace("doCollisions_deep_1_1 OK " + moto1 + " vs " + moto2);
                           count++;
                        }
                     }
                  }
               }
             }
            if (moto1.eventIntersection() && moto1.crash != null){
                SMoto motox = moto1.crash ;
                motox.undoNext();
             }

         }

      }
      DMath.trace("== end doCollisions_level: found " + count);
      return count;
   }



private SMoto verifyCollision(SMoto moto, int distance){
    double tStart = moto.time;
    for(SMoto xmoto : (ArrayList <SMoto>) this) {
         if(xmoto.eventLive() || xmoto.eventDone()) {
            if(moto.nodeDistance(xmoto) <= distance) {

            }
         }
    }
    return null;
}
/*
Like Multi, but updates after intersection

*/
  public void doTestCollisions(SMoto moto, int distance) {
      if(moto == null) {
         return;
      }
      int count = 0;
      ArrayList collMotos = new ArrayList(16);
      Cpoint multi = null;
      for(SMoto xmoto : (ArrayList <SMoto>) this) {
         if(xmoto.eventLive() || xmoto.eventDone()) {
            if(moto.nodeDistance(xmoto) <= distance) {
                  DMath.tracelocal("basicIntersection for " + xmoto.id);
                  if(moto.basicIntersection(xmoto) != null) {

                     if(multi == null) {
                        multi = moto.end;
                     }
                     if(multi.isAttract(moto.end)) {
                        collMotos.add((E) xmoto);
                     }
                     else {
                        collMotos.clear();
                        multi = moto.end;
                        collMotos.add((E) xmoto);
                     }
                }
            }
         }
      }

// cleanup
   for(int i = 0; i <  collMotos.size(); i++){
       SMoto dmoto = (SMoto)collMotos.get(i);
       if (dmoto.eventDead()){
           collMotos.remove(i--);
        }
  //     if ()
      }

 // sets collisions
   for(SMoto amoto : (ArrayList <SMoto>) collMotos) {
            amoto.undoNext();
            amoto.event = MotoEvent.INTERSECTION;
            amoto.end   = multi;
            amoto.time  = amoto.start.distance(amoto.end);
            amoto.crash = moto;
       }
    int ndone = 0;
    int nsuper = 0;

   if(collMotos.size() > 0) {
    // updates
         ndone = 0;
         nsuper = 0;
         for(SMoto bmoto : (ArrayList <SMoto>) collMotos) {
          if(bmoto.eventDone()) {
               ndone++;
            }
          if(bmoto.getDeep() > 1) {
               nsuper++;
            }
          }
 // does multi collision
    SMoto base = null;

    if (moto.getDeep() >1 &&  nsuper >= 1){
        // closes all super
              for(SMoto bmoto : (ArrayList <SMoto>) collMotos) {
                   if(bmoto.getDeep() > 1) {
                      bmoto.undoNext();
                   }
                   base = bmoto;
                   bmoto.setDone();
                   bmoto.crash = moto;
                   bmoto.next = null;
              }
       moto.setDone();
       moto.crash = base;
       moto.next = null;

        }


      DMath.trace("  doTestCollisions for " + moto.id + " count is: " + collMotos.size() + " done: "+ ndone
           + " super: "+ nsuper  );
      }
      DMath.trace("  doTestCollisions end standard - winner is  " + moto.crash);
   }

/**
 * The method... doMultiCollisions
 * @param moto SMoto
 * @param level int
 */
   public SMoto doMultiCollisions(SMoto moto, int distance, int deep) {
      if(moto == null) {
         return null;
      }
      int count = 0;
      ArrayList collMotos = new ArrayList(16);
      Cpoint multi = null;
      for(SMoto xmoto : (ArrayList <SMoto>) this) {
         if(xmoto.eventLive() || xmoto.eventDone()) {
            if(moto.nodeDistance(xmoto) <= distance  && xmoto.deep <= deep) {
               if(!moto.inParents(xmoto) && !xmoto.inParents(moto)) {
                  DMath.trace("doMultiCollision test for " + xmoto.getId());
                  if(moto.testSimpleIntersection(xmoto)) {
// undoes previous intersection
 //                    if(xmoto.next != null) {
 //                        xmoto.undoNext();
 //                        }

                     if(multi == null) {
                        multi = moto.end;
                     }
                     if(multi.isAttract(moto.end)) {
                        collMotos.add((E) xmoto);
                     }
                     else {
                        collMotos.clear();
                        multi = moto.end;
                        collMotos.add((E) xmoto);
                     }
                  }
                  else {
                     /* empty statement */
                  }
               }
            }
         }
      }

     int ndone = 0;
     int nsuper = 0;
/*
     for(SMoto bmoto : (ArrayList <SMoto>) collMotos) {
          if(bmoto.eventDone()) {
               ndone++;
            }
            if(bmoto.getDeep() > 1) {
               nsuper++;
            }
          }
*/

 // undoes previous intersection, only if not SUPER case
 //if (!(moto.getDeep() >1 &&  nsuper >= 1))
   for(SMoto amoto : (ArrayList <SMoto>) collMotos) {
      if(amoto.getDeep() > 1) {
            DMath.trace("multi: test undoNext for "+amoto);
  //      if ( !multi.isAttract(amoto.end)){
  //          DMath.trace("multi: test undoNext ok");
            amoto.undoNext();
            }
       }
// cleanup
   for(int i = 0; i <  collMotos.size(); i++){
       SMoto dmoto = (SMoto)collMotos.get(i);
       if (dmoto.eventDead()){
           collMotos.remove(i--);
        }
      }

   if(collMotos.size() > 0) {
    // updates
         ndone = 0;
         nsuper = 0;
         for(SMoto bmoto : (ArrayList <SMoto>) collMotos) {
          if(bmoto.eventDone()) {
               ndone++;
            }
          if(bmoto.getDeep() > 1) {
               nsuper++;
            }
          }
 // frequent cases:
 /*
          if (moto.getDeep() >1 && collMotos.size() ==2 && ndone == 2){
// stop
            DMath.trace(" multi3-2 done: "+moto+" vs "+(SMoto)collMotos.get(0)+" vs "+(SMoto)collMotos.get(1));
            moto.setDone();
            return;
            }
    if (moto.getDeep() >1 &&  collMotos.size() ==3 &&  nsuper == 1){
             for(SMoto cmoto : (ArrayList <SMoto>) collMotos) {
                cmoto.setDone();
             }
         DMath.trace(" multi4-S done: "+moto+" vs "+(SMoto)collMotos.get(0)+" vs "+(SMoto)collMotos.get(1)+" vs "+(SMoto)collMotos.get(2));
         moto.setDone();
         return;
*/
// does multi collision
    SMoto base = null;

    if (moto.getDeep() >0  &&  nsuper >= 1){
        // closes all super
              for(SMoto bmoto : (ArrayList <SMoto>) collMotos) {
                  if(bmoto.getDeep() > 1) {
                      bmoto.undoNext();
                      bmoto.crash = moto;
                      bmoto.next = null;

                   }
/*
                   if(bmoto.getDeep()== 1){
 //                     bmoto.setDone();
                   } else {

                      doMultiCollisions(bmoto, distance);
                      if (bmoto.crash != moto)
                         return bmoto;
                      base = bmoto;

                   }
                   bmoto.crash = moto;
                   bmoto.next = null;
              }
 //      moto.setDone();
       moto.crash = base;
       moto.next = null;

        }
        */
          else {
            // do nothing: winner is only last
            /*
          for(SMoto bmoto : (ArrayList <SMoto>) collMotos) {

            // old does couples processing
                    if (base == null){
                        base = bmoto;
                    }else{
                      base.crash = bmoto;
                      bmoto.crash = base;
                      SMoto x = null;
                      if (moto.isLeft(bmoto.start)) {
                        x =   intersectionOrder(bmoto, base);
                      } else {
                        x =  intersectionOrder(base,bmoto);
                      }
                  //    intersectionOrder(SMoto motoL, SMoto motoR)
                  //    SMoto x = intersection(base, bmoto);
                      if ( x != null){
                         base = x;
                         borderCollision(base);
                         base.event = MotoEvent.INTERSECTION;
                         base.end   = multi;
                         base.time  = base.start.distance(base.end);
                         }

 // choses only one border
         base.crash = moto;
         moto.crash = base;


                   }
             }
 //        base.crash = moto;
 //        moto.crash = base;
    }
*/

   /*
    old_old
         if (moto.getDeep() >1 && collMotos.size() ==2 && ndone == 0 && nsuper ==0){
            DMath.trace(" multi3-0 done: "+moto+" vs "+(SMoto)collMotos.get(0)+" vs "+(SMoto)collMotos.get(1));
// continue, using only collMotos[1]
            if (moto.motoL.nodeDistance((SMoto)collMotos.get(0)) == 1){
                moto.motoL = (SMoto) collMotos.get(0);
            } else {
                moto.motoR = (SMoto) collMotos.get(0);
            }
            ((SMoto)collMotos.get(0)).setDone();
            moto.setIntersection();
            moto.crash = (SMoto) collMotos.get(1);
            ((SMoto) collMotos.get(1)).crash = moto;

           return;
          }
*/

        }
      }
    }
      DMath.trace("  doMultiCollision for " + moto.id + " count is: " + collMotos.size() + " done: "+ ndone
           + " super: "+ nsuper  );
      }
      DMath.trace("  doMultiCollision end standard - winner is  " + moto.crash);
      return moto;
   }

/**
 * The method... doCollisions
 * @param moto SMoto
 * @param level int
 */
   public void doCollisions(SMoto moto, int distance) {
      if(moto == null) {
         return;
      }
      int count = 0;
      for(SMoto xmoto : (ArrayList <SMoto>) this) {
         if(xmoto.eventLive() || xmoto.eventDone()) {
            if(moto.nodeDistance(xmoto) <= distance) {
               if(xmoto != moto) {
                  if(DMath.trace) {
                     System.out.print("doCollisions_moto test for " + xmoto.id);
                  }
                  if(moto.testSimpleIntersection(xmoto)) {
                     DMath.trace(" ok ");
                     count++;
                  }
                  else {
                     /* empty statement */
                     DMath.trace(" none ");
                  }
               }
            }
         }
      }
      DMath.trace("   end doCollision for " + moto.id + ": winner is  " + moto.crash);
   }

/**
 * The method... doProcessIntersections
 * @return int
 */
   public int doProcessIntersections() {
      int count = 0;
//      DMath.trace("doProcessIntersections START ");
      for(int i = 0; i < this.size(); i++) {
         SMoto moto = (SMoto) this.get(i);
         if(moto.eventIntersection()) {
            lastMotoProcessed = intersection(moto, moto.crash);
            DMath.trace("  doProcessIntersection OK: " + moto + " vs " + moto.crash + " > " + lastMotoProcessed);
         }
         count++;
      }
      return count;
   }

/**
 *  newmoto in lastMotoProcessed
 * @param moto SMoto
 */
   public void doProcessIntersection(SMoto moto) {
      DMath.trace("doProcessIntersections_moto start for "+ moto);
      if(moto.eventIntersection()) {
         if(moto.crash.getDeep() > 2) {
            lastMotoProcessed = intersection(moto, moto.crash);
            DMath.trace("  doProcessIntersection SUPER " + moto + " vs " + moto.crash + " > " + lastMotoProcessed);
         }
         else {
            if(moto.nodeDistance(moto.crash) <= 1) {
               lastMotoProcessed = intersection(moto, moto.crash);
               if (lastMotoProcessed != null){
                  DMath.trace("  doProcessIntersection OK: " + moto + " vs " + moto.crash + " > " + lastMotoProcessed);
                 } else {
                DMath.trace("  doProcessIntersection NULL");
//?
                moto.setDone();
               }
            }
            else {
               myChar.addCrossPointGlyph(moto.end.x, moto.end.y, 0.2);
               DMath.trace("  doProcessIntersection BAD [distance " + moto.nodeDistance(moto.crash) + " > 1] " + moto + " vs " + moto.crash);
   //?
               moto.setDone();
            }
         }
      }
      else {

         DMath.trace("ERROR: BAD DO_PROCESS call for > " + moto);
   //      moto.setDone();
      }
   }



   public SMoto intersection(SMoto moto1, SMoto moto2) {
// extra tests
      if(!(moto1.eventIntersection() && moto2.eventIntersection())) {
              DMath.tracelocal("intesection bad #1: no 2 INTERSECTIONS");
          return null;
      }
      if(!(moto1.crash == moto2 && moto2.crash == moto1)) {
           DMath.tracelocal("intesection bad #2: no 2 crash");
         return null;
      }
      SMoto moto_left = moto1;
      SMoto moto_right = moto2;
      if(!moto_left.isLeft(moto_right.start)&& moto_right.isLeft(moto_left.start)) {
         moto_left = moto2;
         moto_right = moto1;
      }
      return intersectionOrder(moto_left, moto_right);
   }

/**
 * The method... intersection
 * @param moto1 SMoto
 * @param moto2 SMoto
 * @return SMoto
 */
   public SMoto intersectionOrder(SMoto motoL, SMoto motoR) {
// extra tests
      if(!(motoL.eventIntersection() && motoR.eventIntersection())) {
              DMath.tracelocal("intesection bad #1: no 2 INTERSECTIONS");
          return null;
      }
      if(!(motoL.crash == motoR && motoR.crash == motoL)) {
           DMath.tracelocal("intesection bad #2: no 2 crash");
         return null;
      }
     DMath.tracelocal("Intersection processing L:" + motoL + " vs R:" + motoR);
 // border segments
      Cpoint l1 = motoL.getLeftPoint();
      Cpoint l2 = l1.getLeftPoint();
      Cpoint r1 = motoR.getRightPoint();
      Cpoint r2 = r1.getRightPoint();
if (l1.isAttract(r2)|| l2.isAttract(r1)|| l1.isAttract(r1)|| l2.isAttract(r2)){
     DMath.tracelocal(" intersection ERROR: confusion R/L");
       SMoto x = motoL;
       motoL = motoR;
       motoR = x;
       l1 = motoL.getLeftPoint();
       l2 = l1.getLeftPoint();
       r1 = motoR.getRightPoint();
       r2 = r1.getRightPoint();
}

      if((l1 == null) || (l2 == null) || (r1 == null) || (r2 == null)) {
         DMath.trace(" intersection ERROR:null l1 ="+l1+" l2 ="+l2+" r1 ="+r1+" r2 ="+r2);
         return null;
      }
//      if ( DMath.trace && (motoL.getId()== testMoto || motoR.getId() == testMoto)) {
//         myChar.addSquarePointGlyph(l1.x, l1.y, 0.2);
//         myChar.addCrossPointGlyph(l2.x, l2.y, 0.2);
//         myChar.addSquarePointGlyph(r1.x, r1.y, 0.2);
//         myChar.addCrossPointGlyph(r2.x, r2.y, 0.2);
//      }

      Cpoint start = motoL.end;
// build new moto
      SMoto newmoto;
// translating points
      Cpoint n1 = Cpoint.translateSegment(l1, l2, start);
      Cpoint n3 = Cpoint.translateSegment(r1, r2, start);
   // if ((motoL.getId()== testMoto)|| (motoR.getId() == testMoto))
 //       DMath.tracelocal(" 3 points 1V3: ("+n1.x +", "+n1.y+ ")| ("+start.x +", "+start.y+ ") | ("+n3.x +", "+n3.y+ ")" );
// here test direction

      newmoto = new SMoto(motoL, motoR, n1, start, n3);
      newmoto.life = Math.min(motoL.time + motoL.life, motoR.time + motoR.life);
// update old moto
      motoL.setDone();
      motoL.next = newmoto;
      motoR.setDone();
      motoR.next = newmoto;
// add newmoto
      this.addMoto(newmoto);
//      myChar.addCrossPointGlyph(newmoto.start.x, newmoto.start.y, 0.2);
      DMath.tracelocal(" intersection ok-> " + newmoto);
      return newmoto;
   }

/**
 * The method... doSimplifyFrontals
 * @return int
 */
   public int doSimplifyFrontals() {
      int count = 0;
        DMath.tracelocal("=== start  doSimplifyFrontals ");
      for(int i = 1; i < this.size(); i++) {
         SMoto moto1 = (SMoto) this.get(i);
// processes
         for(int j = 0; j < i; j++) {
            SMoto moto2 = (SMoto) this.get(j);
            if(moto1.simplifyFrontal(moto2)) {
               count++;
            }
         }
      }
      return count;
   }

/**
 * The method... findRoundCandidate
 * @return SMoto
 */
   private SMoto findRoundCandidate(boolean up) {
      Random random = new Random();
      SMoto motoCandidate = null;
      int count = -2;
      double test = (up ? 10000: -10000);
      for(SMoto moto : (ArrayList <SMoto>) this) {
         if(moto.eventBorder() && moto.deep == 1 &&  moto.start.isBase()) {
            if(moto.borderP != null) {
               count++;
               if(((test < moto.start.y) ^ up) &(random.nextBoolean())) {
                  test = moto.start.y;
                  motoCandidate = moto;
               }
            }
         }
      }
      if (count < 4) return null;  // old 13
      return motoCandidate;
   }

/**
 * The method... doRoundStart
 */
   static SMoto restart = null;


   public SMoto doRoundStart(int count) {
    //TODO infinite loop here

      SMoto motoSplit = findRoundCandidate(count % 2 == 1);
      if(motoSplit != null) {
         Cpoint split = new Cpoint((motoSplit.start.x + motoSplit.end.x) / 2, (motoSplit.start.y + motoSplit.end.y) / 2);
         SMoto moto = splitBorderMoto(motoSplit, split);
         if(moto == null) {
            DMath.trace("!!! ERROR : null SPLIT");
            myChar.addSquarePointGlyph(split.x, split.y, 0.2);
            restart = null;
            return null;
         }
// intersection

         motoSplit.end = split;
         moto.end = split;
         motoSplit.setIntersection();
         moto.setIntersection();
         motoSplit.crash = moto;
         moto.crash = motoSplit;
         DMath.trace("SPLIT DONE : " + motoSplit + " >> " + moto);
         SMoto motox = intersection(moto, motoSplit);
         if(motox != null) {
            myChar.addSquarePointGlyph(split.x, split.y, 0.2);
            motox.setNew();
   //         motox.reflexDir();

            restart = new SMoto(motox);
            //restart.reflexDir();
    //        restart.motoR = moto;
    //        restart.motoL = motoSplit;
            restart.motoL = moto;
            restart.motoR = motoSplit;
            //
           borderCollision(motox);
            doCollisions(motox,1);
            DMath.trace("ROUND FOUND : " + motox);
            return motox;
         }
         else {
            DMath.trace("!!! ERROR : null INTERSECTION");
   //         myChar.addSquarePointGlyph(split.x, split.y, 0.2);
            restart = null;
            return null;
         }
      }
     DMath.trace("!!! ERROR : null CANDIDATE");
     restart = null;
     return null;
  }


   public SMoto doStartCollisions(int step) {
      SMoto fastMoto = null;
      SMoto moto = null;
      if (step == 2){
// only deep 1
          for(int i = 0; i < this.size() - 1; i++) {
              moto = (SMoto) this.get(i);
    // conditions for start moto
              if( moto.deep == 1 && moto.eventDone() &&
                     moto.crash != null &&
                     moto.crash.deep == 1 &&
                     moto.crash.eventDone() &&
                     moto.nodeDistance(moto.crash) == 1 &&
                     moto.next != null &&
                     !moto.next.eventDead() &&
                     !moto.next.eventDone()  &&
                     moto.next.next == null ) {
    // restore moto
                 fastMoto = moto.next;
                 fastMoto.restoreBorder();
    //
                 restart = null;
                 return fastMoto;
             }
          }
// after linear, now round starts
      fastMoto =  doRoundStart(1);
      return fastMoto;
      }
// step 2,
// any deep
   if (step == 3){
      for(int i = 0; i < this.size() - 1; i++) {
        moto = (SMoto) this.get(i);
// conditions for start moto
         if(  moto.eventDone() &&
                 moto.crash != null &&
                 moto.crash.eventDone() &&
                 moto.next != null &&
                 !moto.next.eventDead()&&
                 !moto.next.eventDone()  &&
                 moto.next.next == null ) {
// restore moto
             fastMoto = moto.next;
// done error, borderP == null
             if (fastMoto.borderP !=null)
                 fastMoto.restoreBorder();
//
             restart = null;
             return fastMoto;
         }
      }
   }
    return fastMoto;
   }

   public SMoto doNextLinear(SMoto moto) {
      if(moto != null) {
         if(moto.next != null) {
              if(!moto.next.eventDead()) {
                    return moto.next;
              }
             DMath.trace ("doNextLinear ERR - next null not live: " +moto.next);
             return null;
             }
           DMath.trace ("doNextLinear ERR - next null for " +moto);
          return null;
      }
        DMath.trace ("doNextLinear ERR - moto null");
        return null;
   }



/**
 * The method... doNextLinear
 * @return SMoto
 */
   public SMoto doNextLinear() {
      if(lastMotoProcessed != null) {
         if(lastMotoProcessed.eventIntersection()) {
            if(lastMotoProcessed.crash != null) {
               int dist = lastMotoProcessed.nodeDistance(lastMotoProcessed.crash);
                DMath.trace ("doNextLinear, distance is "+dist);
               if(dist < 2) {
                  return lastMotoProcessed;
               }
            return null;
            }
          DMath.trace ("doNextLinear ERR: crash null for" +lastMotoProcessed );
             return null;
         }
           DMath.trace ("doNextLinear ERR: not intersction for" +lastMotoProcessed);
          return null;
      }
        DMath.trace ("doNextLinear ERR: lastMotoProcessed null");
        return null;
   }

/**
 * The method... doCleanup
 * @return boolean
 */
   public boolean doCleanup() {
      int count = 0;
      for(SMoto moto : (ArrayList <SMoto>) this) {
         if(moto.eventBorder()) {
            count++;
            moto.setDead();
         }
      }
      return(count > 0);
   }

/**
 * =================================================== EXPLOSION
 *after doCollisions
 * @return SMoto
 */
   public SMoto doFirstCollisions() {
      double small = 1000000;
      SMoto fastMoto = null;
      for(int i = 0; i < this.size() - 1; i++) {
         SMoto moto1 = (SMoto) this.get(i);
         SMoto moto2 = (SMoto) this.get(i + 1);
         if(moto1.eventIntersection() && moto1.deep == 1 &&
             moto2.eventIntersection() && moto2.deep == 1 &&
             moto1.crash == moto2 && moto2.crash == moto1) {
            if(moto1.time > DMath.attractRadius && moto1.time < small) {
               small = moto1.time;
               fastMoto = moto1;
            }
         }
      }
      return fastMoto;
   }


/**
 * ====================   Moto step 3: processes a moto event
 * @param moto1 SMoto
 * @param i int
 * @return int
 */
   public int processEvent(SMoto moto1, int i) {
      if(i > 61) {
         return 0;
      }
      if(moto1 == null) {
         return 0;
      }
      if(moto1.eventFrontal()) {
         SMoto moto2 = moto1.crash;
         DMath.trace(i + " CASE FRONTAL " + moto1 + " vs " + moto2);
// new (false) border for moto1
         moto1.end = moto1.borderP = moto2.start;
         if(moto2.deep == 1) {
            moto1.border1 = moto2.pr;
            moto1.border2 = moto2.pl;
         }
         else {
            moto1.border1 = moto2.motoR.start;
            moto1.border2 = moto2.motoL.start;
         }
         moto1.crash = moto2;
         if(moto2.eventDone()) {
            moto1.setDone();
         }
         else {
            moto1.setBadBorder();
         }
         moto2.setDead();
         if(moto2.deep == 1) {
            moto1.deep = 1;
         }
         moto1.time = moto1.start.distance(moto1.end);
//     myChar.addSqarePointGlyph(moto1.end.x, moto1.end.y, 0.1);
//     myChar.addSqarePointGlyph(moto1.start.x, moto1.start.y, 0.1);
         return 2;
      }
      if(moto1.eventIntersection()) {
         SMoto moto2 = moto1.crash;
         if(moto2.crash == moto1) {
            DMath.trace(i + " CASE INTERSECTION " + moto1 + " vs " + moto2);
            lastMotoProcessed = intersection(moto1, moto2);
            return 3;
         }
         moto1.setBadBorder();
         return 5;
      }
      if(moto1.eventBorder()) {
         moto1.setBadBorder();
         return 4;
      }
      DMath.trace("WARNING: unknow event");
// TODO
      return 0;
   }

/**
 *  ============================= utities
 * first processable
 * @return SMoto
 */
   private SMoto findFirst() {
      double small = 1000000;
      SMoto fastMoto = null;
      for(SMoto moto : (ArrayList <SMoto>) this) {
         if(moto.eventProcessable()) {
            if(moto.crash.crash == moto) {
               if((moto.time > DMath.attractRadius) && (moto.time < small)) {
                  small = moto.time;
                  fastMoto = moto;
               }
            }
         }
      }
      return fastMoto;
   }

/**
 * The method... findNext
 * @return SMoto
 */
   private SMoto findNext() {
      SMoto tmp = lastMotoProcessed;
      int job = 3;
      int x2 = 1000;
      for(SMoto moto : (ArrayList <SMoto>) this) {
         if(moto == lastMotoProcessed) {
            if(lastMotoProcessed.crash == lastMotoProcessed) {
               return lastMotoProcessed;
            }
            while(job == 3) {
               doBorderCollisions();
               doCollisions(3);
               if(tmp.crash == null) {
                  return null;
               }
               job = processEvent(tmp.crash, x2);
               x2 ++;
            }
            lastMotoProcessed = tmp;
            return lastMotoProcessed;
         }
      }
      return null;
   }

/**
 * The method... findNear
 * @return SMoto
 */
   private SMoto findNear() {
      double small = 1000000;
      SMoto fastMoto = null;
      for(SMoto moto : (ArrayList <SMoto>) this) {
         if(moto.eventProcessable() && moto != lastMotoProcessed) {
            if(moto.crash.crash == moto) {
               int d = moto.nodeDistance(lastMotoProcessed);
               if(d < small) {
                  small = d;
                  fastMoto = moto;
               }
            }
         }
      }
      if(small < 8) {
         return fastMoto;
      }
      return null;
   }

/**
 * tot processable motos count
 * @return int
 */
   private int findTotal() {
      int count = 0;
      for(SMoto moto : (ArrayList <SMoto>) this) {
         if(moto.eventLive()) {
            count++;
         }
      }
      return count;
   }

/**
 * final cleanup
 */
   public void doneMotos() {
      for(SMoto moto : (ArrayList <SMoto>) this) {
      if((!moto.eventDone() && moto.deep == 1)||((! moto.eventDead()) && moto.crash == null)) {
//      if(!moto.eventDone() && moto.deep == 1)  {
            borderCollision(moto);
            for(SMoto moto2 : (ArrayList <SMoto>) this) {
               if (moto2.eventAny())

             moto.basicIntersection(moto2) ;
                }
             if (moto.end == null){
                moto.setDead();
             } else
             moto.setDone();
            }
      }
   }

/**
 * The method... adjustLast
 * makes the first and last points the same
 */
   public void killDangling() {
    for(SMoto moto : (ArrayList <SMoto>) this) {
         if(!(moto.eventDone()||moto.eventDead())) {
            if (moto.motoL == null || moto.motoL.end != moto.start ||
                moto.motoR == null || moto.motoR.end != moto.start)
                    moto.setDead();
          }
      }
   }
}
