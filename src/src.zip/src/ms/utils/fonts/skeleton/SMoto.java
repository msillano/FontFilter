//@source: D:\User\Documents\progetti2016\stickfonts\font_filter\src\ms\ utils\fonts\skeleton\SMoto.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
// package and import
package ms.utils.fonts.skeleton;

import ms.utils.DMath;
import ms.utils.fonts.Cfont;
import ms.utils.fonts.Cchar;
import ms.utils.fonts.Cpath;
import ms.utils.fonts.Cpoint;

/**
 * This enum...
 */
enum MotoEvent {

   /* enum global variables */
   NEW,
   FRONTAL,
   INTERSECTION,
   BORDER,
   BADBORDER,
   DONE,
   DEAD

}


/**
 * The method... SMoto
 * <br />Source build by JStruct [charset UTF-8].<br />
 *@version 1.00.00  build 1 2016.02.01
 *@author Sillano
 */
public class SMoto {

   /* class global variables */
   public Cpoint start;
   public Cpoint end = null;
   public Cpoint dir = null;
   double life = 0;
   public SMoto crash = null;
   public double time = 100000;
   MotoEvent event = MotoEvent.NEW;
   SMoto motoL = null;
   SMoto motoR = null;
   public SMoto next = null;
   public Cpoint border1 = null;
   public Cpoint border2 = null;
   public Cpoint borderP = null;
   public Cchar myChar;
   SDrome myDrome;
   int id;
   public Cpoint pl = null;
   public Cpoint pr = null;
   int deep = 1;
// ======================================= SETTER/GETTER
/**
 * The method... eventNew
 * @return boolean
 */
   public boolean eventNew() {
      return event == MotoEvent.NEW;
   }

/**
 *boolean eventNone(){return event ==  MotoEvent.NONE ;}
 *public boolean eventCollision(){return event ==  MotoEvent.COLLISION ;}
 * @return boolean
 */
   public boolean eventFrontal() {
      return event == MotoEvent.FRONTAL;
   }

/**
 * The method... eventIntersection
 * @return boolean
 */
   public boolean eventIntersection() {
      return event == MotoEvent.INTERSECTION;
   }

/**
 * The method... eventBorder
 * @return boolean
 */
   public boolean eventBorder() {
      return event == MotoEvent.BORDER;
   }

/**
 * The method... eventBadBorder
 * @return boolean
 */
   public boolean eventBadBorder() {
      return event == MotoEvent.BADBORDER;
   }

/**
 * The method... eventDone
 * @return boolean
 */
   public boolean eventDone() {
      return event == MotoEvent.DONE;
   }

/**
 * The method... eventDead
 * @return boolean
 */
   public boolean eventDead() {
      return event == MotoEvent.DEAD;
   }

/**
 * The method... eventProcessable
 * @return boolean
 */
   public boolean eventProcessable() {
      return eventFrontal() || eventIntersection();
   }

/**
 * The method... eventLive
 * @return boolean
 */
   public boolean eventLive() {
      return eventBorder() || eventFrontal() || eventIntersection();
   }
  public boolean eventAny() {
      return ! eventDead();
   }

/**
 * The method... setDone
 */
   public void setDone() {
      event = MotoEvent.DONE;
   }

/**
 * The method... setDead
 */
   public void setDead() {
      if(motoL != null && motoL.crash == this) {
         motoL.crash = null;
 //        motoL.restoreBorder();
      }
      if(motoR != null && motoR.crash == this) {
         motoR.crash = null;
 //        motoR.restoreBorder();
      }
      event = MotoEvent.DEAD;
   }

/**
 * The method... setBadBorder
 */
   public void setBadBorder() {
      event = MotoEvent.BADBORDER;
   }

/**
 * The method... setNew
 */
   public void setNew() {
      event = MotoEvent.NEW;
   }

/**
 * The method... setBorder
 */
   public void setBorder() {
      event = MotoEvent.BORDER;
   }

/**
 * The method... setIntersection
 */
   public void setIntersection() {
      event = MotoEvent.INTERSECTION;
   }

/**
 * The method... getId
 * @return int
 */
   public int getId() {
      return id;
   }

/**
 * The method... setId
 * @param n int
 */
   public void setId(int n) {
      id = n;
   }

/**
 * The method... getDeep
 * @return int
 */
   public int getDeep() {
      return deep;
   }


//============================== CONSTRUCTORS
/**
 * The constructor SMoto
 */
   public SMoto() {
      super();
   }

/**
 * firsth generation border moto OK
 * @param p1 Cpoint
 * @param p2 Cpoint
 * @param p3 Cpoint
 * @param aChar Cchar
 */
   public SMoto(Cpoint p1, Cpoint p2, Cpoint p3, Cchar aChar) {
      super();
      start = p2;
      event = MotoEvent.NEW;
      myChar = aChar;
      deep = 1;
      dir = Cpoint.pointBisector(p1, p2, p3);
// dir normalization 0.2..0.4
      while(start.distance(dir) > 2) {
         dir = new Cpoint(start.x + 0.5 * (dir.x - start.x), start.y + 0.5 * (dir.y - start.y));
      }
      while(start.distance(dir) < 1) {
         dir = new Cpoint(start.x + 2 * (dir.x - start.x), start.y + 2 * (dir.y - start.y));
      }
      this.pl = p3;
      this.pr = p1;
      if(Cpoint.isLeft(pr, start, dir)) {
 //        this.pl = p1;
 //        this.pr = p3;
         reflexDir();
      }
   }

/**
 * second generation motos OK
 * @param moto1 SMoto
 * @param moto2 SMoto
 * @param p1 Cpoint
 * @param p2 Cpoint
 * @param p3 Cpoint
 */
   public SMoto(SMoto lmoto, SMoto rmoto, Cpoint p1, Cpoint p2, Cpoint p3) {
      super();
      start = lmoto.end;
      event = MotoEvent.NEW;
      myChar = lmoto.myChar;
      deep = Math.max(lmoto.deep, rmoto.deep) + 1;
// translation
      Cpoint pd = Cpoint.pointBisector(p1, p2, p3);
      dir  = Cpoint.translateSegment(p2, pd, start);
// dir normalization 1..2
      int guard =0;
      while(start.distance(dir) > 2) {
         dir = new Cpoint(start.x + 0.5 * (dir.x - start.x), start.y + 0.5 * (dir.y - start.y));
         if (guard++ >8) break;
      }
      guard = 0;
      while(start.distance(dir) < 1) {
         dir = new Cpoint(start.x + 2 * (dir.x - start.x), start.y + 2 * (dir.y - start.y));
         if (guard++ >8) break;
      }
      this.motoL = lmoto;
      this.motoR = rmoto;
    // OK: good direction for intersection
 //   if ( Cpoint.cosA(motoL.start,start,dir) > 0)
 //               reflexDir();
   }


 public SMoto(SMoto moto) {
   super();
   start = moto.start;
   end = moto.end ;
   dir = moto.dir;
   life = moto.life;
   crash = moto.crash;
   time = moto.time;
   event = moto.event;
   motoL = moto.motoL;
   motoR = moto.motoR;
   next = moto.next;
   border1 = moto.border1;
   border2 = moto.border2;
   borderP = moto.borderP;
   myChar =moto.myChar;
   myDrome=moto.myDrome;
 //  int id;
   pl = moto.pl;
   pr = moto.pr;
   deep = moto.deep;
}

// ========================================== PUBLIC
/**
 * math stuff
 * @param p Cpoint
 * @return boolean
 */
   public boolean isLeft(Cpoint p) {
      return Cpoint.isLeft(this.start, this.dir, p);
   }

/**
 * The method... getLeftPoint
 * @return Cpoint
 */
   public Cpoint getLeftPoint() {
      SMoto oldL = this;
      int count = 0;
      while(oldL.deep > 1) {
        if (count++ > 50) break;
         oldL = oldL.motoL;
      }
// border point
      return oldL.start;
   }

/**
 * The method... getRightPoint
 * @return Cpoint
 */
   public Cpoint getRightPoint() {
      SMoto oldR = this;
      int count = 0;
      while(oldR.deep > 1) {
         if (count++ > 50) break;
         oldR = oldR.motoR;
      }
// border point
      return oldR.start;
   }


public double getAngle(){
    if( DMath.quasiEqual(dir.x - start.x, 0)) return 90;
    double tan =( dir.y -start.y)/(dir.x - start.x);
    double ang = (Math.atan(tan)* 360) / (2* Math.PI);
    return Math.round(ang*100)/100;
}


public  void undoNext(){
    if (eventDead()) return;
    if (this.next != null){
        DMath.trace("  UNDONEXT for " + this);
        this.next.kill(this);
       }

}

public  void kill( SMoto moto){
    if (this.next != null){
        this.next.kill(moto);
       }
     event = MotoEvent.DEAD;
     DMath.trace("--- Kills for " + this);
     if (motoL != null && motoL != moto ){
         DMath.trace("--- Border for " + motoL);
         motoL.restoreBorder();
         motoL.next = null;
     }

     if (motoR != null && motoR != moto ){
         DMath.trace("--- Border for " + motoR);
         motoR.restoreBorder();
         motoR.next = null;
     }
}

public  void undo( ){
    DMath.trace("\n--- UNDO for " + this);
    if (this.next != null){
        this.next.killup(this);
        restoreBorder();
       }
}

private void killup( SMoto moto){
     DMath.trace("--- KILLUP for " + this);
    if (this.next != null){
        this.next.killup(moto);
    }
     if ((motoL != moto)&&(motoL != null))
         motoL.killdown(moto);
     if ((motoR != moto)&&(motoR != null))
         motoR.killdown(moto);
     setDead();
}

private void killdown(SMoto moto){
        if (this == moto) return;
        DMath.trace("--- KILLDOWN for " + this);
        if (this.deep == 1){
            restoreBorder();
            return;
         }
      if ((motoL != moto)&&(motoL != null) && (motoL.deep >1))
         motoL.killdown(moto);
      if ((motoR != moto)&&(motoR != null) && (motoR.deep >1))
         motoR.killdown(moto);
      if ((motoL != null) && (motoL.deep == 1)&&(motoR != null) && (motoR.deep == 1)){
          restoreBorder();
      } else {
          setDead();
      }

}
/**
 * The method... cosAngle
 * @param p Cpoint
 * @return double
 */
   private double cosAngle(Cpoint p) {
// angle p, this.start, this.dir
      return Cpoint.cosA(p, this.start, this.dir);
   }


 /*
 * @return String
 */
   public String toString() {
      return "@" + id + "(" + deep + ")"+getStatusString()+"["+ getAngle()+"][" + start + end + "]";
   }

/**
 * The method... getStatusString
 * @return String
 */
   public String getStatusString() {
      switch (event) {
         case NEW:
            return "NEW";
         case FRONTAL:
            return "FRONTAL";
         case INTERSECTION:
            return "INTERSECTION";
         case BORDER:
            return "BORDER";
         case BADBORDER:
            return "BADBORDER";
         case DONE:
            return "DONE";
         case DEAD:
            return "DEAD";
         default:
            return "UNKNOW";
      }
   }
/**
 * The method... nodeDistance
 * @param moto SMoto
 * @return int
 */
   public int nodeDistance(SMoto moto) {
      int dist1 = 100;
      int dist2 = 100;
      int dist3 = 100;
      int dist4 = 100;
      Cpoint p1 = this.getRightPoint();
      Cpoint p2 = moto.getLeftPoint();
      Cpath border = p1.getPath();
      if(border == p2.getPath()) {
         dist1 = Math.abs(border.indexOf(p1) - border.indexOf(p2));
         if(dist1 > border.size() / 2) {
            dist1 = (border.size() - 1 - dist1);
         }
      }
      p1 = this.getLeftPoint();
      p2 = moto.getRightPoint();
      border = p1.getPath();
      if(border == p2.getPath()) {
         dist2 = Math.abs(border.indexOf(p1) - border.indexOf(p2));
         if(dist2 > border.size() / 2) {
            dist2 = (border.size() - 1 - dist2);
         }
      }
      p1 = moto.getRightPoint();
      p2 = this.getRightPoint();
      border = p1.getPath();
      if(border == p2.getPath()) {
         dist3 = Math.abs(border.indexOf(p1) - border.indexOf(p2));
         if(dist3 > border.size() / 2) {
            dist3 = (border.size() - 1 - dist3);
         }
      }
      p1 = moto.getLeftPoint();
      p2 = this.getLeftPoint();
      border = p1.getPath();
      if(border == p2.getPath()) {
         dist4 = Math.abs(border.indexOf(p1) - border.indexOf(p2));
         if(dist4 > border.size() / 2) {
            dist4 = (border.size() - 1 - dist4);
         }
      }
      dist1 = Math.min(dist1, dist2);
      dist3 = Math.min(dist3, dist4);
      return Math.min(dist1, dist3);
   }

public boolean inParents(SMoto moto){
    if (this==moto) return true;
    boolean itis = false;
    if (this.motoL !=  null)
        itis |= this.motoL.inParents(moto);
    if (this.motoR !=  null)
        itis |= this.motoR.inParents(moto);
    return itis;
}
/**
 * ======================================== private
 */
   void undoCrash() {
      if(this.crash != null) {
         this.crash.restoreBorder();
      }
   }

/**
 * ok
 */
   void reflexDir() {
      dir.x = start.x - (dir.x - start.x);
      dir.y = start.y - (dir.y - start.y);
   }
/*
 * Test interse3ction
 * If found, modify only this, return crashPoint;
 */

   public Cpoint quietIntersection(SMoto bMoto) {
// no dead motos
      if(this.eventDead() || bMoto.eventDead()) {
         DMath.tracelocal("  quietIntersection BAD ["+ id +"] vs ["+bMoto.id +"]: one DEAD ");
         return null;
      }
// no 2 done
      if(this.eventDone() && bMoto.eventDone()) {
        DMath.tracelocal("  quietIntersection BAD ["+ id +"] vs ["+bMoto.id +"]: DONE && DONE ");
          return null;
      }
// test parallel case: may be frontal
      if(Cpoint.isParallel(this.start, this.end, bMoto.start, bMoto.end)) {
         DMath.tracelocal("  quietIntersection BAD ["+ id +"] vs ["+bMoto.id +"]: parallel ");
        return null;
      }
 // test not parent
       if(bMoto.inParents(this)  || this.inParents(bMoto)) {
         DMath.tracelocal("  quietIntersection BAD ["+ id +"] vs ["+bMoto.id +"]: parents ");
         return null;
      }

// test  intersection
 //    if ( DMath.trace) System.out.print(" moto:"+bMoto.id );
      Cpoint crashPoint = Cpoint.getIntersection(this.start, this.end, bMoto.start, bMoto.end, true, true, true);
// modifies only this
     if (crashPoint != null){
     crashPoint = myChar.attraction(crashPoint);
     double dist1 = this.start.distance(crashPoint);
     double dist2 = bMoto.start.distance(crashPoint);
     if ((time > dist1 || DMath.quasiEqual(time, dist1)) &&
         (bMoto.time > dist2 || DMath.quasiEqual(bMoto.time, dist2)) ) {
// ok
         DMath.tracelocal("  quietIntersection OK ["+ id +"] vs ["+bMoto.id +"]");
         return crashPoint;
      }
      DMath.tracelocal("  quietIntersection BAD ["+ id +"] vs ["+bMoto.id +"]: out time ");
      return null;
     }
      DMath.tracelocal(" quietIntersection BAD ["+ id +"] vs ["+bMoto.id +"]: no Cross point ");
      return null;

      }


   public Cpoint basicIntersection(SMoto bMoto) {
// no dead motos
      if (bMoto==null || bMoto.start == null || bMoto.end == null || this.start == null || this.end == null)
        return null;
      if(this.eventDead() || bMoto.eventDead()) {
         DMath.tracelocal("  basicIntersection BAD ["+ id +"] vs ["+bMoto.id +"]: one DEAD ");
         return null;
      }
// no 2 done
      if(this.eventDone() && bMoto.eventDone()) {
        DMath.tracelocal("  basicIntersection BAD ["+ id +"] vs ["+bMoto.id +"]: DONE && DONE ");
          return null;
      }
// test parallel case: may be frontal
      if(Cpoint.isParallel(this.start, this.end, bMoto.start, bMoto.end)) {
         DMath.tracelocal("  basicIntersection BAD ["+ id +"] vs ["+bMoto.id +"]: parallel ");
        return null;
      }
 // test not parent
       if(bMoto.inParents(this)  || this.inParents(bMoto)) {
         DMath.tracelocal("  basicIntersection BAD ["+ id +"] vs ["+bMoto.id +"]: parents ");
         return null;
      }

// test  intersection
 //    if ( DMath.trace) System.out.print(" moto:"+bMoto.id );
      Cpoint crashPoint = Cpoint.getIntersection(this.start, this.end, bMoto.start, bMoto.end, true, true, true);
// modifies only this
     if (crashPoint != null){
     crashPoint = myChar.attraction(crashPoint);
     double dist1 = this.start.distance(crashPoint);
     double dist2 = bMoto.start.distance(crashPoint);
     if ((time > dist1 || DMath.quasiEqual(time, dist1)) &&
         (bMoto.time > dist2 || DMath.quasiEqual(bMoto.time, dist2)) ) {
// ok
         DMath.tracelocal("  basicIntersection OK ["+ id +"] vs ["+bMoto.id +"]");
         this.event = MotoEvent.INTERSECTION;
         this.end   = crashPoint;
         this.time  = start.distance(end);
         this.crash = bMoto;
         return crashPoint;
      }
      DMath.tracelocal("  basicIntersection BAD ["+ id +"] vs ["+bMoto.id +"]: out time ");
      return null;
     }
      DMath.tracelocal(" basicIntersection BAD ["+ id +"] vs ["+bMoto.id +"]: no Cross point ");
      return null;

      }

/**
 * ===============================================  UNDER TEST
 * @param bMoto SMoto
 * @return boolean
 */

   public boolean testSimpleIntersection(SMoto bMoto) {
// test  intersection
      Cpoint crashPoint =  basicIntersection(bMoto);
      if(crashPoint == null) {
        return false;
      }
// updates bmoto:
         bMoto.event = MotoEvent.INTERSECTION;
         bMoto.end   = crashPoint;
         bMoto.time  = bMoto.start.distance(bMoto.end);
         bMoto.crash = this;
         return true;
    }

/**
 * The method... simplifyFrontal
 * cuts extrems exra done points
 * @param bMoto SMoto
 * @return boolean
 */
   boolean simplifyFrontal(SMoto bMoto) {
// no dead moto
      if(this.eventDead() || bMoto.eventDead()) {
         return false;
      }
// no 2 border motos
      if(this.deep == 1 && bMoto.deep == 1) {
         return false;
      }

// no dangling motos
//     if(this.eventBorder() || bMoto.eventBorder()) {
//         return false;
//      }
//   DMath.trace(" simplifyFrontal for "+this+" vs "+ bMoto);
  if (this.eventDone() && bMoto.eventDone()) return false;  // no 2 done
// if (this.eventBadBorder() || bMoto.eventBadBorder()) return false;
// test collinear case: frontal
// linked special
        // inside
      if (bMoto==null || bMoto.start == null || bMoto.end == null || this.start == null || this.end == null)
        return false;

      if(Cpoint.isCollinear(this.start, this.end, bMoto.start, bMoto.end)) {

 //        if(this.end.quasiEqual(bMoto.start)) {
            if (this.end.isAttract(bMoto.start)){

            if(Cpoint.isInSegment(this.start, this.end, bMoto.end) ||
               Cpoint.isInSegment(bMoto.start, bMoto.end, start)) {
               if (deep >1 ){
                   if (DMath.trace) System.out.println(" ** simplifyFrontal rule 3 dead "+ bMoto + " vs " + this);
                   bMoto.end = start;
                   setDead();
                   bMoto.setDone();
                } else {
                   if (DMath.trace) System.out.println(" ** simplifyFrontal rule 3 dead "+ this + " vs " + bMoto);
                   end = bMoto.start;
                   bMoto.setDead();
                   setDone();
               }

               return true;
            }
            else {
               return false;
            }
         }
 // inside
         if(Cpoint.isInSegment(this.start, this.end, bMoto.start) &&
             Cpoint.isInSegment(this.start, this.end, bMoto.end) &&
              bMoto.deep > 1   ) {
            if (DMath.trace) System.out.println(" ** simplifyFrontal ruie 1 dead "+ bMoto + " vs " + this);
            bMoto.setDead();
            setDone();
            return true;
         }
         if(Cpoint.isInSegment(bMoto.start, bMoto.end, this.start) &&
             Cpoint.isInSegment(bMoto.start, bMoto.end, this.end) &&
               deep > 1  ) {
            if (DMath.trace) System.out.println(" ** simplifyFrontal ruie 2 dead "+ this + " vs "+ bMoto);
            setDead();
            bMoto.setDone();
            return true;
         }

// linked
         if((Cpoint.isInSegment(bMoto.start, bMoto.end, this.start) ||
             Cpoint.isInSegment(start, end, bMoto.start))) {
                if (deep >1){
                   if (DMath.trace) System.out.println(" ** simplifyFrontal ruie 5 dead "+ this + " vs " + bMoto);
                   bMoto.end = start;
                   bMoto.setDone();
                   setDead();
                   }
                 else  {
                  if (DMath.trace) System.out.println(" ** simplifyFrontal ruie 5 dead "+ bMoto + " vs " + this);
                  end = bMoto.start;
                  setDone();
                  bMoto.setDead();
                  }
            return true;
         }
 //        if (DMath.trace) System.out.println("collinear but out segment");
         return false;
      }
//      DMath.trace("NOT collinear");
      return false;
   }

/**
 * ====================================== EXPLODE
 */
   public void restoreBorder() {
      this.end = this.borderP;
      this.crash = null;
      this.event = MotoEvent.BORDER;
      this.time = this.start.distance(this.borderP);
   }

/**
 * test for collision using bMoto
 * bMoto is rigth of this
 * @return boolean
 */
   public boolean doCrash_old(SMoto bMoto) {
// test collinear
      if(this.eventDone() && bMoto.eventDone()) {
         return false;
      }
      if(Cpoint.isCollinear(this.start, this.end, bMoto.start, bMoto.end)) {
// inside ??
//       double distA = (this.start.distance(bMoto.start)/2);
         if(Cpoint.isInSegment(this.start, this.end, bMoto.start) || Cpoint.isInSegment(this.start, this.end, bMoto.end)) {
//      if ((bMoto.time >= distA)&& (time >= distA))
            time = this.start.distance(bMoto.start);
            end = myChar.attraction(bMoto.start);
            this.crash = bMoto;
            bMoto.time = bMoto.start.distance(this.start);
            bMoto.end = myChar.attraction(start);
            bMoto.crash = this;
            bMoto.event = MotoEvent.FRONTAL;
            return true;
         }
         return false;
      }
// test  intersection
      Cpoint crashPoint = Cpoint.getIntersection(this.start, this.end, bMoto.start, bMoto.end, true, true, true);
      if(crashPoint == null) {
         return false;
      }
      if(crashPoint.quasiEqual(start) || crashPoint.quasiEqual(bMoto.start)) {
         return false;
      }
      double dist1 = this.start.distance(crashPoint);
      double dist2 = bMoto.start.distance(crashPoint);
// real point
      if((bMoto.time >= dist2) && (time >= dist1)) {
         if(dist2 + bMoto.life > dist1 + life) {
            this.undoCrash();
            bMoto.time = dist2;
            bMoto.end = myChar.attraction(crashPoint);
            bMoto.crash = this;
            bMoto.event = MotoEvent.INTERSECTION;
         }
         else {
            this.time = dist1;
            this.end = myChar.attraction(crashPoint);
            this.crash = bMoto;
            this.event = MotoEvent.INTERSECTION;
            bMoto.undoCrash();
            return true;
         }
      }
      return false;
   }

/**
 * The method... testFrontal_old
 * @param bMoto SMoto
 * @return boolean
 */
   boolean testFrontal_old(SMoto bMoto) {
// no dead motos
      if(this.eventDead() || bMoto.eventDead()) {
         return false;
      }
// no 2 done
      if(this.eventDone() && bMoto.eventDone()) {
         return false;
      }
// if (this.eventBadBorder() || bMoto.eventBadBorder()) return false;
// test collinear case: frontal
      if(Cpoint.isCollinear(this.start, this.end, bMoto.start, bMoto.end)) {
// inside ??
//       double distA = (this.start.distance(bMoto.start)/2);
         if(Cpoint.isInSegment(this.start, this.end, bMoto.start) || Cpoint.isInSegment(this.start, this.end, bMoto.end)) {
//      if ((bMoto.time >= distA)&& (time >= distA))
            time = this.start.distance(bMoto.start);
            end = myChar.attraction(bMoto.start);
            this.crash = bMoto;
//            event = MotoEvent.DONE;
            bMoto.time = bMoto.start.distance(this.start);
            bMoto.end = myChar.attraction(start);
            bMoto.crash = this;
            bMoto.event = MotoEvent.FRONTAL;
            return true;
         }
      }
      return false;
   }

}

